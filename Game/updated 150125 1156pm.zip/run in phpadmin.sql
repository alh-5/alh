-- Create database tables for DB Tambola
-- Run this in phpMyAdmin of InfinityFree

-- Games table
CREATE TABLE IF NOT EXISTS `games` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `game_code` varchar(10) NOT NULL,
  `game_name` varchar(100) NOT NULL,
  `status` enum('waiting','started','ended') DEFAULT 'waiting',
  `current_number` int(11) DEFAULT NULL,
  `called_numbers` text DEFAULT '[]',
  `patterns_enabled` text DEFAULT '["top_line","middle_line","bottom_line","corners","full_house"]',
  `auto_call_speed` int(11) DEFAULT 3000,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `started_at` datetime DEFAULT NULL,
  `ended_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `game_code` (`game_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tickets table
CREATE TABLE IF NOT EXISTS `tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_code` varchar(20) NOT NULL,
  `game_id` int(11) DEFAULT NULL,
  `player_name` varchar(100) DEFAULT NULL,
  `player_email` varchar(100) DEFAULT NULL,
  `numbers` text DEFAULT '[]',
  `purchase_status` enum('available','sold','used') DEFAULT 'available',
  `purchased_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ticket_code` (`ticket_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Test table (simple)
CREATE TABLE IF NOT EXISTS `games_test` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `game_code` varchar(10) NOT NULL,
  `game_name` varchar(100) NOT NULL,
  `status` varchar(20) DEFAULT 'waiting',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert test data
INSERT INTO `games_test` (`game_code`, `game_name`) VALUES 
('TAM123', 'Friday Night Tambola'),
('TAM456', 'Saturday Special');

-- Insert sample game
INSERT INTO `games` (`game_code`, `game_name`) VALUES 
('TAMB001', 'Test Game 1');