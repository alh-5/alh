<?php
require_once 'config.php';

header('Content-Type: application/json');

// Get action
$action = $_GET['action'] ?? ($_POST['action'] ?? '');

switch($action) {
    case 'get_games':
        $games_result = $conn->query("SELECT * FROM games WHERE status IN ('waiting', 'started') ORDER BY created_at DESC");
        $games_html = '';
        if($games_result->num_rows > 0) {
            while($game = $games_result->fetch_assoc()) {
                $called = json_decode($game['called_numbers'] ?? '[]', true);
                $count = count($called);
                
                $games_html .= '<div class="col-md-6 mb-3">
                    <div class="game-card h-100">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <h5>' . htmlspecialchars($game['game_name']) . '</h5>
                                <p class="mb-2">Code: <strong>' . $game['game_code'] . '</strong></p>
                                <p class="mb-2">Numbers: <strong>' . $count . '/90</strong></p>
                            </div>
                            <span class="badge bg-' . 
                                ($game['status'] == 'waiting' ? 'warning' : 
                                 ($game['status'] == 'started' ? 'success' : 'danger')) . 
                                ' p-2">' . strtoupper($game['status']) . '</span>
                        </div>
                        <div class="mt-3">
                            <a href="game.php?code=' . $game['game_code'] . '" 
                               class="btn btn-custom w-100">
                                <i class="fas fa-play me-2"></i>Join Game
                            </a>
                        </div>
                    </div>
                </div>';
            }
        } else {
            $games_html = '<div class="col-12 text-center py-5">
                <i class="fas fa-gamepad fa-3x text-muted mb-3"></i>
                <h5>No active games</h5>
                <p class="text-muted">Check back later</p>
            </div>';
        }
        echo json_encode(['games' => $games_html]);
        break;
        
    case 'get_game_state':
        $code = $_GET['code'] ?? '';
        $result = $conn->query("SELECT current_number, called_numbers, status FROM games WHERE game_code = '$code'");
        if($result->num_rows > 0) {
            $game = $result->fetch_assoc();
            $numbers = json_decode($game['called_numbers'] ?? '[]', true) ?: [];
            echo json_encode([
                'current_number' => $game['current_number'],
                'called_numbers' => $numbers,
                'status' => $game['status']
            ]);
        } else {
            echo json_encode(['error' => 'Game not found']);
        }
        break;
        
    case 'get_ticket':
        $ticket_code = $_POST['ticket_code'] ?? '';
        $game_code = $_POST['game_code'] ?? '';
        
        // Get game ID
        $game_result = $conn->query("SELECT id FROM games WHERE game_code = '$game_code'");
        if($game_result->num_rows === 0) {
            echo json_encode(['success' => false, 'error' => 'Game not found']);
            break;
        }
        $game = $game_result->fetch_assoc();
        $game_id = $game['id'];
        
        // Get ticket
        $stmt = $conn->prepare("SELECT numbers, player_name FROM tickets WHERE ticket_code = ? AND game_id = ?");
        $stmt->bind_param("si", $ticket_code, $game_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if($result->num_rows > 0) {
            $ticket = $result->fetch_assoc();
            $numbers = json_decode($ticket['numbers'], true);
            echo json_encode([
                'success' => true,
                'numbers' => $numbers,
                'player_name' => $ticket['player_name'] ?? 'Player'
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'error' => 'Ticket not found or invalid game'
            ]);
        }
        break;
        
    case 'get_tickets_by_player_name':
        $player_name = $_POST['player_name'] ?? '';
        $game_code = $_POST['game_code'] ?? '';
        
        if(empty($player_name) || empty($game_code)) {
            echo json_encode(['success' => false, 'error' => 'Missing parameters']);
            exit;
        }
        
        // Get game ID
        $stmt = $conn->prepare("SELECT id FROM games WHERE game_code = ?");
        $stmt->bind_param("s", $game_code);
        $stmt->execute();
        $result = $stmt->get_result();
        $game = $result->fetch_assoc();
        
        if(!$game) {
            echo json_encode(['success' => false, 'error' => 'Game not found']);
            exit;
        }
        
        $game_id = $game['id'];
        
        // Search tickets by player name (case-insensitive, partial match)
        $search_name = "%" . $player_name . "%";
        $stmt = $conn->prepare("
            SELECT t.*, 
                   (SELECT COUNT(*) FROM wins w WHERE w.ticket_code = t.ticket_code AND w.game_id = t.game_id) as is_claimed
            FROM tickets t 
            WHERE t.game_id = ? AND LOWER(t.player_name) LIKE LOWER(?)
            ORDER BY t.ticket_code
        ");
        $stmt->bind_param("is", $game_id, $search_name);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $tickets = [];
        while($row = $result->fetch_assoc()) {
            $tickets[] = [
                'ticket_code' => $row['ticket_code'],
                'player_name' => $row['player_name'],
                'numbers' => json_decode($row['numbers'], true),
                'is_claimed' => $row['is_claimed'] > 0
            ];
        }
        
        if(empty($tickets)) {
            echo json_encode(['success' => false, 'error' => 'No tickets found for this player']);
            exit;
        }
        
        echo json_encode(['success' => true, 'tickets' => $tickets]);
        break;
        
    case 'purchase_ticket':
        $game_code = $_POST['game_code'] ?? '';
        $player_name = $_POST['player_name'] ?? '';
        $player_email = $_POST['player_email'] ?? '';
        
        // Validate inputs
        if(empty($game_code) || empty($player_name) || empty($player_email)) {
            echo json_encode(['error' => 'All fields are required']);
            break;
        }
        
        // Get game
        $game_result = $conn->query("SELECT id FROM games WHERE game_code = '$game_code' AND status = 'waiting'");
        if($game_result->num_rows === 0) {
            echo json_encode(['error' => 'Game not found or already started']);
            break;
        }
        $game = $game_result->fetch_assoc();
        $game_id = $game['id'];
        
        // Get available ticket
        $stmt = $conn->prepare("SELECT ticket_code FROM tickets WHERE game_id = ? AND purchase_status = 'available' LIMIT 1");
        $stmt->bind_param("i", $game_id);
        $stmt->execute();
        $ticket_result = $stmt->get_result();
        
        if($ticket_result->num_rows === 0) {
            echo json_encode(['error' => 'No tickets available for this game']);
            break;
        }
        
        $ticket = $ticket_result->fetch_assoc();
        $ticket_code = $ticket['ticket_code'];
        
        // Update ticket
        $stmt = $conn->prepare("UPDATE tickets SET player_name = ?, player_email = ?, purchase_status = 'sold', purchased_at = NOW() WHERE ticket_code = ?");
        $stmt->bind_param("sss", $player_name, $player_email, $ticket_code);
        
        if($stmt->execute()) {
            echo json_encode([
                'success' => true,
                'ticket_code' => $ticket_code,
                'message' => 'Ticket purchased successfully!'
            ]);
        } else {
            echo json_encode(['error' => 'Failed to purchase ticket']);
        }
        break;
        
    case 'call_number':
        $game_code = $_POST['game_code'] ?? $game_id = $_POST['game_id'] ?? 0;
        
        if($game_code) {
            $result = $conn->query("SELECT id FROM games WHERE game_code = '$game_code'");
            if($result->num_rows > 0) {
                $game = $result->fetch_assoc();
                $game_id = $game['id'];
            }
        }
        
        $result = $conn->query("SELECT called_numbers FROM games WHERE id = $game_id");
        if($result->num_rows > 0) {
            $game = $result->fetch_assoc();
            $called = json_decode($game['called_numbers'] ?? '[]', true);
            
            if(count($called) >= 90) {
                echo json_encode(['error' => 'All numbers called']);
                break;
            }
            
            // Generate unique number
            $all_numbers = range(1, 90);
            $available = array_diff($all_numbers, $called);
            
            if(count($available) > 0) {
                $new_number = $available[array_rand($available)];
                $called[] = $new_number;
                $called_json = json_encode($called);
                
                $conn->query("UPDATE games SET current_number = $new_number, called_numbers = '$called_json' WHERE id = $game_id");
                echo json_encode(['success' => true, 'number' => $new_number]);
            } else {
                echo json_encode(['error' => 'No numbers left']);
            }
        } else {
            echo json_encode(['error' => 'Game not found']);
        }
        break;
        
    case 'auto_call_number':
        $game_code = $_POST['game_code'] ?? '';
        
        $result = $conn->query("SELECT id, auto_call_delay FROM games WHERE game_code = '$game_code' AND status = 'started'");
        if($result->num_rows > 0) {
            $game = $result->fetch_assoc();
            $game_id = $game['id'];
            $delay = $game['auto_call_delay'];
            
            if($delay > 0) {
                // Call number (same logic as above)
                $called_result = $conn->query("SELECT called_numbers FROM games WHERE id = $game_id");
                $game_data = $called_result->fetch_assoc();
                $called = json_decode($game_data['called_numbers'] ?? '[]', true);
                
                if(count($called) < 90) {
                    $all_numbers = range(1, 90);
                    $available = array_diff($all_numbers, $called);
                    $new_number = $available[array_rand($available)];
                    $called[] = $new_number;
                    $called_json = json_encode($called);
                    
                    $conn->query("UPDATE games SET current_number = $new_number, called_numbers = '$called_json' WHERE id = $game_id");
                    echo json_encode(['success' => true, 'number' => $new_number]);
                }
            }
        }
        break;
        
    case 'get_recent_winners':
        $game_id = $_GET['game_id'] ?? 0;
        
        $query = "SELECT * FROM wins WHERE game_id = $game_id ORDER BY claimed_at DESC LIMIT 5";
        $result = $conn->query($query);
        $winners = [];
        
        while($row = $result->fetch_assoc()) {
            $winners[] = $row;
        }
        
        echo json_encode(['winners' => $winners]);
        break;
        
    case 'get_first_winners':
        $game_id = $_GET['game_id'] ?? 0;
        
        // Get first winner for each pattern (earliest claim)
        $query = "
            SELECT w1.* 
            FROM wins w1
            WHERE w1.game_id = ? 
            AND w1.claimed_at = (
                SELECT MIN(w2.claimed_at) 
                FROM wins w2 
                WHERE w2.game_id = w1.game_id 
                AND w2.pattern_type = w1.pattern_type
            )
            ORDER BY w1.claimed_at DESC
            LIMIT 5
        ";
        
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $game_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $winners = [];
        while($row = $result->fetch_assoc()) {
            $winners[] = $row;
        }
        
        echo json_encode(['winners' => $winners]);
        break;
        
    case 'get_claimed_patterns':
        $game_id = $_GET['game_id'] ?? 0;
        
        // Get all patterns that have been claimed in this game
        $query = "SELECT DISTINCT pattern_type FROM wins WHERE game_id = ? ORDER BY claimed_at";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $game_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $patterns = [];
        while($row = $result->fetch_assoc()) {
            $patterns[] = $row['pattern_type'];
        }
        
        echo json_encode(['success' => true, 'patterns' => $patterns]);
        break;
        
    case 'ping':
        // Update session or keep connection alive
        session_start();
        $_SESSION['last_ping'] = time();
        echo json_encode(['success' => true]);
        break;
        
    case 'claim_prize':
        $game_code = $_POST['game_code'] ?? '';
        $ticket_code = $_POST['ticket_code'] ?? '';
        $pattern = $_POST['pattern'] ?? '';
        $prize = floatval($_POST['prize'] ?? 0);
        $player_name = $_POST['player_name'] ?? '';
        
        // Get game ID
        $game_result = $conn->query("SELECT id FROM games WHERE game_code = '$game_code'");
        if($game_result->num_rows === 0) {
            echo json_encode(['success' => false, 'error' => 'Game not found']);
            break;
        }
        $game = $game_result->fetch_assoc();
        $game_id = $game['id'];
        
        // Get ticket info
        $ticket_result = $conn->query("SELECT player_name FROM tickets WHERE ticket_code = '$ticket_code' AND game_id = $game_id");
        if($ticket_result->num_rows === 0) {
            // If ticket not found, use provided player name
            if(empty($player_name)) {
                echo json_encode(['success' => false, 'error' => 'Ticket not found and no player name provided']);
                break;
            }
        } else {
            $ticket = $ticket_result->fetch_assoc();
            $player_name = $ticket['player_name'];
        }
        
        // Check if already claimed for this pattern
        $claimed_result = $conn->query("SELECT id FROM wins WHERE ticket_code = '$ticket_code' AND pattern_type = '$pattern'");
        if($claimed_result->num_rows > 0) {
            echo json_encode(['success' => false, 'error' => 'Prize already claimed']);
            break;
        }
        
        // Check if pattern already claimed by someone else (first winner check)
        $first_winner_result = $conn->query("SELECT id FROM wins WHERE game_id = $game_id AND pattern_type = '$pattern' LIMIT 1");
        if($first_winner_result->num_rows > 0) {
            echo json_encode(['success' => false, 'error' => 'This pattern has already been claimed by another player']);
            break;
        }
        
        // Insert win
        $stmt = $conn->prepare("INSERT INTO wins (game_id, ticket_code, player_name, pattern_type, prize_amount, claimed_at) VALUES (?, ?, ?, ?, ?, NOW())");
        $stmt->bind_param("isssd", $game_id, $ticket_code, $player_name, $pattern, $prize);
        
        if($stmt->execute()) {
            // If full house claimed, end the game
            if($pattern === 'full_house') {
                $update_stmt = $conn->prepare("UPDATE games SET status = 'ended' WHERE id = ?");
                $update_stmt->bind_param("i", $game_id);
                $update_stmt->execute();
            }
            
            echo json_encode(['success' => true, 'message' => 'Prize claimed successfully']);
        } else {
            echo json_encode(['success' => false, 'error' => 'Failed to claim prize']);
        }
        break;
        
    default:
        echo json_encode(['error' => 'Invalid action']);
        break;
}
?>