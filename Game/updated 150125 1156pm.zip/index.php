<?php
require_once 'config.php';

// Get active games with ticket count
$games_query = "SELECT g.*, 
               (SELECT COUNT(*) FROM tickets t WHERE t.game_id = g.id AND t.purchase_status = 'sold') as sold_tickets
               FROM games g 
               WHERE g.status IN ('waiting', 'started') 
               ORDER BY g.created_at DESC";
$games_result = $conn->query($games_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DB Tambola - Play Online Housie</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #4b6cb7;
            --secondary: #182848;
            --accent: #ff5722;
            --whatsapp: #25D366;
        }
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .hero-section {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            border-radius: 20px;
            padding: 40px 20px;
            color: white;
            margin-bottom: 30px;
            text-align: center;
        }
        .game-card {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.1);
            transition: all 0.3s;
            border: none;
        }
        .game-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 25px rgba(0,0,0,0.15);
        }
        .btn-custom {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            border: none;
            padding: 12px 25px;
            border-radius: 10px;
            font-weight: 600;
            transition: all 0.3s;
        }
        .btn-custom:hover {
            transform: scale(1.05);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        .btn-whatsapp {
            background: var(--whatsapp);
            color: white;
            border: none;
            padding: 12px 25px;
            border-radius: 10px;
            font-weight: 600;
            transition: all 0.3s;
        }
        .btn-whatsapp:hover {
            background: #128C7E;
            transform: scale(1.05);
            box-shadow: 0 5px 15px rgba(37, 211, 102, 0.3);
        }
        .number-badge {
            display: inline-block;
            width: 40px;
            height: 40px;
            line-height: 40px;
            border-radius: 50%;
            background: linear-gradient(135deg, #4CAF50, #2E7D32);
            color: white;
            font-weight: bold;
            margin: 5px;
            text-align: center;
        }
        .modal-backdrop {
            background: rgba(0,0,0,0.5);
        }
        .modal-content {
            border-radius: 20px;
            border: none;
        }
        .game-code-display {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 8px 15px;
            border-radius: 8px;
            font-family: monospace;
            font-size: 1.1em;
            cursor: pointer;
            transition: all 0.3s;
        }
        .game-code-display:hover {
            transform: scale(1.05);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        .share-buttons {
            display: flex;
            gap: 10px;
            margin-top: 10px;
        }
        .share-buttons button {
            flex: 1;
        }
        @media (max-width: 768px) {
            .hero-section h1 {
                font-size: 1.8rem;
            }
            .game-card {
                margin: 10px 5px;
            }
            .share-buttons {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="container py-4">
        <!-- Header -->
        <div class="hero-section">
            <h1 class="display-4 fw-bold mb-3">🎯 DB Tambola</h1>
            <p class="lead mb-4">Play Online Housie with Friends & Family in Real-time</p>
            
            <div class="row">
                <div class="col-md-3 mb-3">
                    <div class="bg-white text-dark p-3 rounded">
                        <i class="fas fa-gamepad fa-2x mb-2 text-primary"></i>
                        <h6>Total Games</h6>
                        <?php $total = $conn->query("SELECT COUNT(*) as c FROM games")->fetch_assoc()['c']; ?>
                        <h4 class="mb-0"><?php echo $total; ?></h4>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="bg-white text-dark p-3 rounded">
                        <i class="fas fa-play-circle fa-2x mb-2 text-success"></i>
                        <h6>Active Games</h6>
                        <?php $active = $conn->query("SELECT COUNT(*) as c FROM games WHERE status='started'")->fetch_assoc()['c']; ?>
                        <h4 class="mb-0"><?php echo $active; ?></h4>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="bg-white text-dark p-3 rounded">
                        <i class="fas fa-ticket-alt fa-2x mb-2 text-warning"></i>
                        <h6>Total Tickets</h6>
                        <?php $tickets = $conn->query("SELECT COUNT(*) as c FROM tickets")->fetch_assoc()['c']; ?>
                        <h4 class="mb-0"><?php echo $tickets; ?></h4>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="bg-white text-dark p-3 rounded">
                        <i class="fas fa-trophy fa-2x mb-2 text-danger"></i>
                        <h6>Total Winners</h6>
                        <?php $winners = $conn->query("SELECT COUNT(*) as c FROM wins")->fetch_assoc()['c']; ?>
                        <h4 class="mb-0"><?php echo $winners; ?></h4>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="row">
            <!-- Active Games -->
            <div class="col-lg-8 mb-4">
                <div class="game-card">
                    <h4 class="mb-4"><i class="fas fa-play-circle me-2"></i> Active Games</h4>
                    <div class="row" id="gamesList">
                        <?php if ($games_result->num_rows > 0): ?>
                            <?php while($game = $games_result->fetch_assoc()): 
                                $called = json_decode($game['called_numbers'] ?? '[]', true);
                                $numbers_count = count($called);
                                $sold_tickets = $game['sold_tickets'];
                                $game_url = "http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . "/game.php?code=" . $game['game_code'];
                            ?>
                                <div class="col-md-6 mb-3">
                                    <div class="game-card h-100">
                                        <div class="d-flex justify-content-between align-items-start">
                                            <div>
                                                <h5><?php echo htmlspecialchars($game['game_name']); ?></h5>
                                                <p class="mb-1">Numbers: <strong><?php echo $numbers_count; ?>/90</strong></p>
                                                <p class="mb-2">Players: <strong><?php echo $sold_tickets; ?></strong></p>
                                            </div>
                                            <span class="badge bg-<?php 
                                                echo $game['status'] == 'waiting' ? 'warning' : 
                                                     ($game['status'] == 'started' ? 'success' : 'danger');
                                            ?> p-2">
                                                <?php echo strtoupper($game['status']); ?>
                                            </span>
                                        </div>
                                        
                                        <!-- Game Code Display -->
                                        <div class="mb-3">
                                            <label class="form-label mb-1">Game Code:</label>
                                            <div class="game-code-display text-center" 
                                                 onclick="copyToClipboard('<?php echo $game['game_code']; ?>', this)">
                                                <strong><?php echo $game['game_code']; ?></strong>
                                                <span class="copy-text ms-2"><i class="fas fa-copy"></i> Copy</span>
                                            </div>
                                        </div>
                                        
                                        <!-- Share Buttons -->
                                        <div class="share-buttons">
                                            <button class="btn btn-custom" 
                                                    onclick="openPurchaseModal('<?php echo $game['game_code']; ?>', '<?php echo htmlspecialchars($game['game_name']); ?>')">
                                                <i class="fas fa-shopping-cart me-2"></i>Buy Ticket
                                            </button>
                                            <button class="btn btn-whatsapp" 
                                                    onclick="shareOnWhatsApp('<?php echo $game['game_name']; ?>', '<?php echo $game['game_code']; ?>')">
                                                <i class="fab fa-whatsapp me-2"></i>Invite
                                            </button>
                                        </div>
                                        
                                        <a href="game.php?code=<?php echo $game['game_code']; ?>" 
                                           class="btn btn-outline-primary w-100 mt-2">
                                            <i class="fas fa-play-circle me-2"></i>Join Game
                                        </a>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <div class="col-12 text-center py-5">
                                <i class="fas fa-gamepad fa-3x text-muted mb-3"></i>
                                <h5>No active games at the moment</h5>
                                <p class="text-muted">Check back later or create a new game</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Recent Numbers -->
                <div class="game-card">
                    <h4 class="mb-3"><i class="fas fa-history me-2"></i>Recent Numbers Called</h4>
                    <div id="recentNumbers">
                        <?php
                        $recent_query = "SELECT called_numbers FROM games WHERE status='started' ORDER BY started_at DESC LIMIT 1";
                        $recent_result = $conn->query($recent_query);
                        if ($recent_result->num_rows > 0) {
                            $game = $recent_result->fetch_assoc();
                            $numbers = json_decode($game['called_numbers'] ?? '[]', true);
                            $recent = array_slice($numbers, -10);
                            foreach(array_reverse($recent) as $num) {
                                echo '<span class="number-badge">' . $num . '</span>';
                            }
                            if(empty($recent)) {
                                echo '<p class="text-muted text-center mb-0">No numbers called yet</p>';
                            }
                        } else {
                            echo '<p class="text-muted text-center mb-0">No active games</p>';
                        }
                        ?>
                    </div>
                </div>
            </div>

            <!-- Sidebar -->
            <div class="col-lg-4">
                <!-- Your Tickets -->
                <div class="game-card mb-4">
                    <h4 class="mb-3"><i class="fas fa-ticket-alt me-2"></i>Your Tickets</h4>
                    <div class="mb-3">
                        <div class="input-group">
                            <input type="text" id="checkTicketCode" class="form-control" 
                                   placeholder="Enter ticket code">
                            <button class="btn btn-primary" onclick="checkTicket()">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </div>
                    <div id="yourTickets">
                        <p class="text-muted text-center">Enter ticket code to view details</p>
                    </div>
                </div>

                <!-- How to Play -->
                <div class="game-card mb-4">
                    <h4 class="mb-3"><i class="fas fa-question-circle me-2"></i>How to Play</h4>
                    <ol class="list-group list-group-numbered">
                        <li class="list-group-item border-0 bg-transparent">thied ticket</li>
                        <li class="list-group-item border-0 bg-transparent">peit bha u ticket id</li>
                        <li class="list-group-item border-0 bg-transparent">join ia ka room</li>
                        <li class="list-group-item border-0 bg-transparent">enter ia u ticket id ha search box</li>
                        <li class="list-group-item border-0 bg-transparent">sa enjoy ka batam good Luck!</li>
                    </ol>
                </div>

                <!-- Admin Access -->
                <div class="game-card">
                    <h4 class="mb-3"><i class="fas fa-user-shield me-2"></i>Admin Access</h4>
                    <a href="admin_login.php" class="btn btn-dark w-100 mb-3">
                        <i class="fas fa-sign-in-alt me-2"></i>Admin Login
                    </a>
                    <div class="text-center">
                        <small class="text-muted">Need help? Contact: support@dbtambola.com</small>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Purchase Ticket Modal -->
    <div class="modal fade" id="purchaseModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Purchase Ticket</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        <strong id="modalGameName"></strong><br>
                        Game Code: <strong id="modalGameCode"></strong>
                    </div>
                    
                    <form id="purchaseForm">
                        <input type="hidden" id="purchaseGameCode" name="game_code">
                        
                        <div class="mb-3">
                            <label class="form-label">Full Name *</label>
                            <input type="text" id="playerName" class="form-control" required 
                                   placeholder="Enter your full name">
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Email Address *</label>
                            <input type="email" id="playerEmail" class="form-control" required 
                                   placeholder="Enter your email">
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Phone Number *</label>
                            <input type="tel" id="playerPhone" class="form-control" required 
                                   placeholder="Enter your phone number">
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Number of Tickets *</label>
                            <select id="ticketCount" class="form-control">
                                <option value="1">1 Ticket </option>
                                <option value="2">2 Tickets </option>
                                <option value="3">3 Tickets </option>
                                <option value="5">5 Tickets </option>
                                <option value="10">10 Tickets </option>
                            </select>
                        </div>
                        
                        <div class="alert alert-warning">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            <strong>Important:</strong> Please save your ticket code. It cannot be recovered.
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-success" onclick="processPurchase()">
                        <i class="fas fa-credit-card me-2"></i>Pay Now
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Ticket Details Modal -->
    <div class="modal fade" id="ticketModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Your Ticket</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div id="ticketDetails"></div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Open purchase modal
        function openPurchaseModal(gameCode, gameName) {
            $('#modalGameCode').text(gameCode);
            $('#modalGameName').text(gameName);
            $('#purchaseGameCode').val(gameCode);
            
            // Reset form
            $('#playerName').val('');
            $('#playerEmail').val('');
            $('#playerPhone').val('');
            $('#ticketCount').val('1');
            
            $('#purchaseModal').modal('show');
        }
        
        // Process purchase
        function processPurchase() {
            const gameCode = $('#purchaseGameCode').val();
            const playerName = $('#playerName').val().trim();
            const playerEmail = $('#playerEmail').val().trim();
            const playerPhone = $('#playerPhone').val().trim();
            const ticketCount = $('#ticketCount').val();
            
            // Validate
            if(!playerName || !playerEmail || !playerPhone) {
                alert('Please fill all required fields');
                return;
            }
            
            if(!validateEmail(playerEmail)) {
                alert('Please enter a valid email address');
                return;
            }
            
            // Process tickets one by one
            let tickets = [];
            let processed = 0;
            
            function purchaseNext() {
                if(processed >= ticketCount) {
                    // All tickets purchased
                    showTickets(tickets);
                    return;
                }
                
                $.ajax({
                    url: 'api.php',
                    method: 'POST',
                    data: {
                        action: 'purchase_ticket',
                        game_code: gameCode,
                        player_name: playerName,
                        player_email: playerEmail,
                        phone: playerPhone
                    },
                    success: function(response) {
                        if(response.success) {
                            tickets.push({
                                code: response.ticket_code,
                                numbers: response.numbers
                            });
                            processed++;
                            purchaseNext();
                        } else {
                            alert('Error: ' + response.error);
                        }
                    },
                    error: function() {
                        alert('Network error. Please try again.');
                    }
                });
            }
            
            $('#purchaseModal').modal('hide');
            purchaseNext();
        }
        
        // Validate email
        function validateEmail(email) {
            const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return re.test(email);
        }
        
        // Show purchased tickets
        function showTickets(tickets) {
            let html = '<div class="text-center">';
            html += '<h4 class="text-success mb-3">🎉 Purchase Successful!</h4>';
            html += '<p>Your ticket(s):</p>';
            
            tickets.forEach((ticket, index) => {
                html += `<div class="alert alert-success mb-2">
                    <strong>Ticket ${index + 1}:</strong> ${ticket.code}<br>
                    <small>Click to view numbers</small>
                </div>`;
            });
            
            html += '<p class="text-danger"><i class="fas fa-exclamation-triangle"></i> Save your ticket codes!</p>';
            html += '<button class="btn btn-primary" onclick="joinGame(\'' + $('#purchaseGameCode').val() + '\')">';
            html += '<i class="fas fa-play me-2"></i>Join Game Now</button>';
            html += '</div>';
            
            $('#ticketDetails').html(html);
            $('#ticketModal').modal('show');
        }
        
        // Join game
        function joinGame(gameCode) {
            window.location.href = 'game.php?code=' + gameCode;
        }
        
        // Check ticket
        function checkTicket() {
            const ticketCode = $('#checkTicketCode').val().trim();
            if(!ticketCode) {
                alert('Please enter ticket code');
                return;
            }
            
            $.ajax({
                url: 'api.php',
                method: 'POST',
                data: {
                    action: 'check_ticket',
                    ticket_code: ticketCode
                },
                success: function(response) {
                    if(response.success) {
                        let html = '<div class="alert alert-success">';
                        html += '<h6>Ticket Details</h6>';
                        html += '<p><strong>Code:</strong> ' + ticketCode + '</p>';
                        html += '<p><strong>Game:</strong> ' + response.game_name + '</p>';
                        html += '<p><strong>Player:</strong> ' + response.player_name + '</p>';
                        html += '<p><strong>Status:</strong> ' + (response.status === 'sold' ? 'Purchased' : 'Available') + '</p>';
                        
                        if(response.patterns_completed && response.patterns_completed.length > 0) {
                            html += '<p><strong>Patterns Completed:</strong> ' + response.patterns_completed.join(', ') + '</p>';
                        }
                        
                        html += '</div>';
                        $('#yourTickets').html(html);
                    } else {
                        $('#yourTickets').html('<div class="alert alert-danger">' + response.error + '</div>');
                    }
                }
            });
        }
        
        // Share on WhatsApp
        function shareOnWhatsApp(gameName, gameCode) {
            const gameUrl = window.location.origin + '/game.php?code=' + gameCode;
            const message = `🎯 Join me in DB Tambola!\n\nGame: ${gameName}\nCode: ${gameCode}\n\nClick to join: ${gameUrl}\n\nLet's play Housie together! 🎱`;
            
            // Encode the message for WhatsApp URL
            const encodedMessage = encodeURIComponent(message);
            const whatsappUrl = `https://wa.me/?text=${encodedMessage}`;
            
            // Open WhatsApp in new tab
            window.open(whatsappUrl, '_blank');
        }
        
        // Copy game code to clipboard
        function copyToClipboard(text, element) {
            navigator.clipboard.writeText(text).then(function() {
                // Show success feedback
                const originalText = element.querySelector('.copy-text').innerHTML;
                element.querySelector('.copy-text').innerHTML = '<i class="fas fa-check"></i> Copied!';
                element.style.background = 'linear-gradient(135deg, #4CAF50, #2E7D32)';
                
                // Revert after 2 seconds
                setTimeout(function() {
                    element.querySelector('.copy-text').innerHTML = originalText;
                    element.style.background = 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)';
                }, 2000);
                
                // Optional: Show toast notification
                showToast('Game code copied to clipboard!');
            }).catch(function(err) {
                console.error('Failed to copy: ', err);
                alert('Failed to copy game code. Please copy manually: ' + text);
            });
        }
        
        // Show toast notification
        function showToast(message) {
            // Create toast element
            const toast = document.createElement('div');
            toast.className = 'position-fixed bottom-0 end-0 p-3';
            toast.style.zIndex = '11';
            
            toast.innerHTML = `
                <div class="toast show" role="alert">
                    <div class="toast-header bg-success text-white">
                        <strong class="me-auto"><i class="fas fa-check-circle me-2"></i>Success</strong>
                        <button type="button" class="btn-close btn-close-white" onclick="this.parentElement.parentElement.remove()"></button>
                    </div>
                    <div class="toast-body">
                        ${message}
                    </div>
                </div>
            `;
            
            document.body.appendChild(toast);
            
            // Auto remove after 3 seconds
            setTimeout(() => {
                if (toast.parentElement) {
                    toast.parentElement.removeChild(toast);
                }
            }, 3000);
        }
        
        // Update games list periodically
        setInterval(function() {
            $.get('api.php?action=get_active_games', function(data) {
                if(data.success && data.games) {
                    $('#gamesList').html(data.games);
                }
            });
        }, 10000);
    </script>
</body>
</html>