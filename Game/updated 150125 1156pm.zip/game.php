<?php
require_once 'config.php';

$game_code = $_GET['code'] ?? '';
if(empty($game_code)) {
    header('Location: index.php');
    exit;
}

// Get game data
$stmt = $conn->prepare("SELECT * FROM games WHERE game_code = ?");
$stmt->bind_param("s", $game_code);
$stmt->execute();
$game_result = $stmt->get_result();
$game = $game_result->fetch_assoc();

if(!$game) {
    die("Game not found!");
}

$called_numbers = json_decode($game['called_numbers'] ?? '[]', true) ?: [];
$patterns_enabled = json_decode($game['patterns_enabled'] ?? '[]', true) ?: [];
$pattern_prizes = json_decode($game['pattern_prizes'] ?? '{}', true) ?: [];
$auto_call_delay = $game['auto_call_delay'] ?? 5;
$game_status = $game['status'] ?? 'waiting';

// Check if Full House has been claimed
$full_house_claimed = false;
$full_house_winner = null;

if($game_status == 'ended') {
    // Get the first Full House winner
    $fh_stmt = $conn->prepare("
        SELECT * FROM wins 
        WHERE game_id = ? AND pattern_type = 'full_house' 
        ORDER BY claimed_at ASC 
        LIMIT 1
    ");
    $fh_stmt->bind_param("i", $game['id']);
    $fh_stmt->execute();
    $fh_result = $fh_stmt->get_result();
    if($fh_winner = $fh_result->fetch_assoc()) {
        $full_house_claimed = true;
        $full_house_winner = $fh_winner;
    }
}

// Get first winners for each pattern for this game
$winners_stmt = $conn->prepare("
    SELECT w1.* 
    FROM wins w1
    WHERE w1.game_id = ? 
    AND w1.claimed_at = (
        SELECT MIN(w2.claimed_at) 
        FROM wins w2 
        WHERE w2.game_id = w1.game_id 
        AND w2.pattern_type = w1.pattern_type
    )
    ORDER BY w1.claimed_at DESC
    LIMIT 5
");
$winners_stmt->bind_param("i", $game['id']);
$winners_stmt->execute();
$winners_result = $winners_stmt->get_result();

// Update last ping time to keep session alive
$_SESSION['last_ping'] = time();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?php echo $game['game_name']; ?> - DB Tambola</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #4b6cb7;
            --secondary: #182848;
            --accent: #ff5722;
        }
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            -webkit-text-size-adjust: 100%;
            -webkit-tap-highlight-color: transparent;
        }
        .game-container {
            max-width: 100%;
            margin: 0;
            padding: 8px;
            padding-bottom: 70px;
            overflow-x: hidden;
        }
        .current-number-display {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            border-radius: 15px;
            padding: 15px 10px;
            color: white;
            text-align: center;
            margin-bottom: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            width: 100%;
            overflow: hidden;
        }
        .current-number {
            font-size: 3.5rem;
            font-weight: bold;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
            color: #ffeb3b;
            animation: pulse 2s infinite;
            line-height: 1;
            word-break: break-word;
        }
        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.05); }
        }
        .game-card {
            background: white;
            border-radius: 12px;
            padding: 15px;
            margin-bottom: 15px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.08);
            overflow: hidden;
        }
        .number-grid {
            display: grid;
            grid-template-columns: repeat(10, 1fr);
            gap: 5px;
            margin-top: 10px;
        }
        .number-cell {
            aspect-ratio: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            font-weight: bold;
            font-size: 0.9rem;
            background: white;
            transition: all 0.3s;
            min-width: 0;
        }
        .number-cell.called {
            background: linear-gradient(135deg, #4CAF50, #2E7D32);
            color: white;
            border-color: #388E3C;
            transform: scale(1.05);
        }
        .ticket-grid {
            display: grid;
            grid-template-columns: repeat(9, 1fr);
            gap: 3px;
            margin: 8px 0;
        }
        .ticket-cell {
            aspect-ratio: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-weight: bold;
            background: #f8f9fa;
            position: relative;
            font-size: 0.8rem;
            min-width: 0;
        }
        .ticket-cell.has-number {
            background: white;
        }
        .ticket-cell.marked {
            background: #FFD700;
            color: #000;
            border-color: #FFC107;
        }
        .ticket-cell.corner {
            background: #ffebee;
            border: 2px solid #FF5722 !important;
        }
        .ticket-cell.corner.marked {
            background: linear-gradient(135deg, #FF9800, #FF5722);
            color: white;
            border-color: #F57C00 !important;
        }
        .pattern-badge {
            display: inline-block;
            padding: 6px 12px;
            margin: 3px;
            border-radius: 15px;
            font-size: 0.8rem;
            font-weight: 600;
            background: #e9ecef;
            color: #495057;
            transition: all 0.3s;
            position: relative;
        }
        .pattern-badge.completed {
            background: #28a745;
            color: white;
            animation: success 1s;
        }
        .pattern-badge.won {
            background: #ffc107;
            color: #000;
            animation: winner 2s infinite;
        }
        .pattern-badge.claimed {
            background: #17a2b8;
            color: white;
        }
        .pattern-badge.claimed-gone {
            background: #6c757d;
            color: white;
            opacity: 0.7;
        }
        @keyframes success {
            0% { transform: scale(1); }
            50% { transform: scale(1.1); }
            100% { transform: scale(1); }
        }
        @keyframes winner {
            0%, 100% { box-shadow: 0 0 8px #ffc107; }
            50% { box-shadow: 0 0 15px #ff9800; }
        }
        .winner-card {
            background: linear-gradient(135deg, #ffd700, #ff9800);
            border-radius: 8px;
            padding: 10px;
            margin: 8px 0;
            animation: slideIn 0.5s;
        }
        @keyframes slideIn {
            from { transform: translateX(-100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        .mobile-controls {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: white;
            padding: 12px 8px;
            box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
            z-index: 1000;
            display: none;
        }
        .voice-control-slider {
            width: 100%;
            margin: 8px 0;
        }
        .winner-announcement {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: linear-gradient(135deg, #ffd700, #ff9800);
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 15px 30px rgba(0,0,0,0.3);
            z-index: 2000;
            display: none;
            text-align: center;
            animation: popup 0.5s;
            width: 90%;
            max-width: 400px;
        }
        .whatsapp-share-btn {
            background: #25D366;
            color: white;
            border: none;
            padding: 6px 12px;
            border-radius: 8px;
            font-weight: bold;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            transition: all 0.3s;
            font-size: 0.8rem;
            margin: 5px auto 0;
            width: auto;
        }
        .whatsapp-share-btn:hover {
            background: #128C7E;
            transform: scale(1.05);
        }
        .whatsapp-share-btn i {
            font-size: 0.9rem;
        }
        .auto-claim-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: #28a745;
            color: white;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.7rem;
        }
        @keyframes popup {
            0% { transform: translate(-50%, -50%) scale(0.5); opacity: 0; }
            100% { transform: translate(-50%, -50%) scale(1); opacity: 1; }
        }
        
        /* Game Ended Overlay */
        .game-ended-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.9);
            z-index: 3000;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            text-align: center;
            padding: 20px;
        }
        .game-ended-content {
            background: linear-gradient(135deg, #ff9800, #ff5722);
            border-radius: 20px;
            padding: 30px;
            max-width: 500px;
            width: 90%;
            animation: popup 0.5s;
        }
        
        /* Claim Button */
        .claim-all-btn {
            background: linear-gradient(135deg, #28a745, #20c997);
            border: none;
            color: white;
            padding: 12px;
            border-radius: 10px;
            font-weight: bold;
            width: 100%;
            margin-top: 10px;
            transition: all 0.3s;
        }
        .claim-all-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(40, 167, 69, 0.3);
        }
        .claim-all-btn:disabled {
            background: #6c757d;
            cursor: not-allowed;
            transform: none;
        }
        
        /* Ticket Display Container */
        .tickets-container {
            margin-top: 15px;
            max-height: 800px;
            overflow-y: auto;
            padding-right: 5px;
        }
        .ticket-display-card {
            background: white;
            border-radius: 10px;
            padding: 12px;
            margin-bottom: 12px;
            border: 2px solid transparent;
            transition: all 0.3s;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }
        .ticket-display-card.active {
            border-color: #007bff;
            box-shadow: 0 5px 15px rgba(0,123,255,0.2);
        }
        .ticket-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 8px;
            padding-bottom: 6px;
            border-bottom: 1px solid #eee;
        }
        .ticket-code {
            font-weight: bold;
            color: #007bff;
        }
        .player-name {
            color: #28a745;
            font-weight: 500;
        }
        
        /* Search Player Section */
        .search-player-section {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 12px;
            margin-bottom: 15px;
            border: 1px solid #dee2e6;
        }
        .player-search-results {
            max-height: 300px;
            overflow-y: auto;
            margin-top: 10px;
            padding: 5px;
        }
        .player-search-item {
            background: white;
            border: 1px solid #dee2e6;
            border-radius: 8px;
            padding: 10px;
            margin-bottom: 8px;
            cursor: pointer;
            transition: all 0.3s;
        }
        .player-search-item:hover {
            background: #e9ecef;
            border-color: #007bff;
        }
        .player-search-item.selected {
            background: #007bff;
            color: white;
            border-color: #0056b3;
        }
        .player-info {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 8px;
        }
        .ticket-count {
            background: #28a745;
            color: white;
            border-radius: 20px;
            padding: 2px 8px;
            font-size: 0.8rem;
            font-weight: bold;
        }
        
        /* Extra small devices (phones, 360px and down) */
        @media (max-width: 360px) {
            .current-number {
                font-size: 2.8rem;
            }
            .game-card {
                padding: 12px;
            }
            .number-cell {
                font-size: 0.8rem;
                padding: 2px;
            }
            .ticket-cell {
                font-size: 0.7rem;
            }
            .pattern-badge {
                padding: 5px 10px;
                font-size: 0.75rem;
            }
            .whatsapp-share-btn {
                padding: 5px 10px;
                font-size: 0.75rem;
            }
            .ticket-display-card {
                padding: 8px;
            }
        }
        
        /* Small devices (phones, 600px and down) */
        @media (max-width: 600px) {
            .current-number {
                font-size: 3rem;
            }
            .game-container {
                padding: 8px 5px;
            }
            .mobile-controls {
                display: flex !important;
            }
            .number-cell {
                font-size: 0.85rem;
                padding: 3px;
            }
            .ticket-cell {
                font-size: 0.75rem;
            }
            .game-card h5 {
                font-size: 1rem;
            }
            .winner-card h6 {
                font-size: 0.9rem;
            }
            .tickets-container {
                max-height: 600px;
            }
        }
        
        /* Medium devices (tablets, 768px and down) */
        @media (max-width: 768px) {
            .game-container {
                padding: 10px 8px;
            }
            .row {
                margin: 0 -5px;
            }
            .col-lg-8, .col-lg-4 {
                padding: 0 5px;
            }
        }
        
        /* Large devices (desktops, 992px and up) */
        @media (min-width: 992px) {
            .game-container {
                max-width: 1200px;
                margin: 0 auto;
                padding: 15px;
            }
        }
        
        /* Prevent zoom on input focus in mobile */
        input, select, textarea {
            font-size: 16px !important;
        }
        
        /* Better touch targets */
        button, .btn, .pattern-badge {
            min-height: 44px;
            min-width: 44px;
        }
        
        /* Improve scrolling */
        .game-container {
            -webkit-overflow-scrolling: touch;
        }
        
        /* Scrollbar styling */
        .tickets-container::-webkit-scrollbar,
        .player-search-results::-webkit-scrollbar {
            width: 6px;
        }
        .tickets-container::-webkit-scrollbar-track,
        .player-search-results::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 10px;
        }
        .tickets-container::-webkit-scrollbar-thumb,
        .player-search-results::-webkit-scrollbar-thumb {
            background: #888;
            border-radius: 10px;
        }
        .tickets-container::-webkit-scrollbar-thumb:hover,
        .player-search-results::-webkit-scrollbar-thumb:hover {
            background: #555;
        }
    </style>
</head>
<body>
   <?php if($full_house_claimed): ?>
<div class="game-ended-overlay" id="gameEndedOverlay">
    <div class="game-ended-content">
        <h1 class="mb-3">🎮 GAME ENDED 🎮</h1>
        <h3 class="mb-2">Full House Claimed!</h3>
        <div class="winner-card mb-4">
            <h4>🏆 <?php echo htmlspecialchars($full_house_winner['player_name']); ?></h4>
            <p class="mb-1">Ticket: <code><?php echo $full_house_winner['ticket_code']; ?></code></p>
            <h2 class="text-success mb-0">₹<?php echo number_format($full_house_winner['prize_amount'], 0); ?></h2>
        </div>
        <p class="mb-4">Thank you for playing <?php echo htmlspecialchars($game['game_name']); ?>!</p>
        
        <!-- Replace this button: -->
        <!-- <a href="index.php" class="btn btn-light btn-lg">
            <i class="fas fa-home me-2"></i>Back to Home
        </a> -->
        
        <!-- With this button: -->
        <button class="btn btn-light btn-lg" onclick="hideGameEndOverlay()">
            <i class="fas fa-forward me-2"></i>Skip
        </button>
    </div>
</div>
<?php endif; ?>
    
    <div class="game-container">
        <!-- Game Header -->
        <div class="current-number-display">
            <div class="row align-items-center g-2">
                <div class="col-4 text-start">
                    <h6 class="mb-1">
                        <i class="fas fa-gamepad me-1"></i><?php echo htmlspecialchars($game['game_name']); ?>
                    </h6>
                    <p class="mb-0 small">Code: <strong><?php echo $game_code; ?></strong></p>
                    <p class="mb-0 small" id="onlineStatus">🟢 Online</p>
                </div>
                <div class="col-4 text-center">
                    <div class="current-number" id="currentNumber">
                        <?php echo $game['current_number'] ?: '--'; ?>
                    </div>
                    <p class="mt-1 mb-0 small">Current Number</p>
                </div>
                <div class="col-4 text-end">
                    <div class="btn-group btn-group-sm">
                        <a href="index.php" class="btn btn-light">
                            <i class="fas fa-home"></i>
                        </a>
                        <button class="btn btn-light" onclick="toggleFullscreen()">
                            <i class="fas fa-expand"></i>
                        </button>
                        <?php if($game['status'] == 'started' && !$full_house_claimed): ?>
                            <button class="btn btn-success" onclick="speakCurrentNumber()">
                                <i class="fas fa-volume-up"></i>
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="row g-2">
            <!-- Left Column - Main Content -->
            <div class="col-lg-8">
                <!-- Number Board -->
                <div class="game-card">
                    <h5 class="mb-2"><i class="fas fa-dice me-2"></i>Numbers (1-90)</h5>
                    <div id="calledNumbersList" class="mb-2">
                        <?php foreach(array_slice($called_numbers, -12) as $num): ?>
                            <span class="badge bg-success me-1 mb-1 fs-6"><?php echo $num; ?></span>
                        <?php endforeach; ?>
                    </div>
                    
                    <div class="number-grid">
                        <?php for($i = 1; $i <= 90; $i++): ?>
                            <div class="number-cell <?php echo in_array($i, $called_numbers) ? 'called' : ''; ?>" 
                                 id="num-<?php echo $i; ?>">
                                <?php echo $i; ?>
                            </div>
                        <?php endfor; ?>
                    </div>
                </div>

                <!-- Player's Tickets Display -->
                <div class="game-card">
                    <h5 class="mb-2"><i class="fas fa-ticket-alt me-2"></i>Player's Tickets</h5>
                    <div id="ticketsContainer" class="tickets-container">
                        <p class="text-muted text-center py-3 small" id="noTicketsMessage">
                            Search for a player by name to display their tickets
                        </p>
                        <!-- Player tickets will be displayed here -->
                    </div>
                </div>
            </div>

            <!-- Right Column - Controls -->
            <div class="col-lg-4">
                <!-- Search Player by Name -->
                <div class="game-card">
                    <h5 class="mb-2"><i class="fas fa-search me-2"></i>Search Player by Name</h5>
                    <div class="search-player-section">
                        <div class="mb-2">
                            <div class="input-group">
                                <input type="text" id="playerName" class="form-control form-control-sm" 
                                       placeholder="Enter full player name">
                                <button class="btn btn-info btn-sm" onclick="searchPlayer()">
                                    <i class="fas fa-search"></i>
                                </button>
                                <button class="btn btn-secondary btn-sm" onclick="clearSearch()" title="Clear">
                                    <i class="fas fa-times"></i>
                                </button>
                            </div>
                        </div>
                        <div id="playerSearchResults" class="player-search-results d-none">
                            <!-- Player search results will appear here -->
                        </div>
                    </div>
                </div>

                <!-- Patterns with Auto Claim -->
                <div class="game-card">
                    <h5 class="mb-2"><i class="fas fa-shapes me-2"></i>Winning Patterns</h5>
                    <div class="mb-2">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="autoClaim" checked>
                            <label class="form-check-label" for="autoClaim">Auto Claim & Show to Host</label>
                        </div>
                    </div>
                    <div id="patternsContainer">
                        <?php foreach($patterns_enabled as $pattern => $enabled): 
                            if($enabled): 
                                $names = [
                                    'top_line' => 'Top Line',
                                    'bottom_line' => 'Bottom Line', 
                                    'corners' => 'Corners',
                                    'middle_line' => 'Middle Line',
                                    'full_house' => 'Full House'
                                ];
                                $prize = $pattern_prizes[$pattern] ?? 0;
                        ?>
                            <div class="pattern-badge" id="pattern-<?php echo $pattern; ?>" style="position: relative;">
                                <?php echo $names[$pattern] ?? ucfirst($pattern); ?>
                                <?php if($prize > 0): ?>
                                    <small class="ms-1">(₹<?php echo $prize; ?>)</small>
                                <?php endif; ?>
                            </div>
                        <?php endif; endforeach; ?>
                    </div>
                    <div id="patternStatus" class="mt-2 small text-muted">
                        Add player tickets to check patterns
                    </div>
                    
                    <!-- Claim All Button -->
                    <button class="claim-all-btn" id="claimAllBtn" onclick="claimAllWinningPatterns()" disabled>
                        <i class="fas fa-flag-checkered me-2"></i>Claim Winning Patterns
                    </button>
                </div>

                <!-- Voice Controls -->
                <div class="game-card">
                    <h5 class="mb-2"><i class="fas fa-volume-up me-2"></i>Voice Settings</h5>
                    <div class="mb-2">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="autoVoice" checked>
                            <label class="form-check-label" for="autoVoice">Auto Announce Numbers</label>
                        </div>
                    </div>
                    <div class="mb-2">
                        <label class="form-label small">Call Speed</label>
                        <input type="range" class="form-range voice-control-slider" id="callSpeed" 
                               min="1" max="30" value="<?php echo $auto_call_delay; ?>">
                        <div class="d-flex justify-content-between small">
                            <span>Fast</span>
                            <span>Normal</span>
                            <span>Slow</span>
                        </div>
                    </div>
                    <div class="mb-2">
                        <label class="form-label small">Voice Speed</label>
                        <input type="range" class="form-range voice-control-slider" id="voiceSpeed" 
                               min="0.5" max="2" step="0.1" value="1">
                        <div class="d-flex justify-content-between small">
                            <span>Slow</span>
                            <span>Normal</span>
                            <span>Fast</span>
                        </div>
                    </div>
                    <button class="btn btn-outline-primary w-100 btn-sm" onclick="testVoice()">
                        <i class="fas fa-play me-2"></i>Test Voice
                    </button>
                </div>

                <!-- First Winners Only -->
                <div class="game-card">
                    <h5 class="mb-2"><i class="fas fa-trophy me-2"></i>First Winners</h5>
                    <div id="winnersList">
                        <?php if($winners_result->num_rows > 0): ?>
                            <?php while($winner = $winners_result->fetch_assoc()): 
                                $pattern_names = [
                                    'top_line' => 'Top Line',
                                    'bottom_line' => 'Bottom Line',
                                    'corners' => 'Corners',
                                    'middle_line' => 'Middle Line',
                                    'full_house' => 'Full House'
                                ];
                            ?>
                                <div class="winner-card" data-winner-id="<?php echo $winner['id']; ?>">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div>
                                            <h6 class="mb-1">🎉 <?php echo $winner['player_name']; ?></h6>
                                            <p class="mb-0 small">Ticket: <code><?php echo $winner['ticket_code']; ?></code></p>
                                        </div>
                                        <div class="text-end">
                                            <span class="badge bg-dark"><?php echo $pattern_names[$winner['pattern_type']]; ?></span>
                                            <h5 class="mb-0 text-success">₹<?php echo number_format($winner['prize_amount'], 0); ?></h5>
                                        </div>
                                    </div>
                                    <?php if($winner['pattern_type'] == 'full_house'): ?>
                                        <button class="whatsapp-share-btn" onclick="shareWinnerOnWhatsApp(
                                            '<?php echo addslashes($winner['player_name']); ?>',
                                            '<?php echo $winner['pattern_type']; ?>',
                                            '<?php echo $winner['ticket_code']; ?>',
                                            <?php echo $winner['prize_amount']; ?>
                                        )">
                                            <i class="fab fa-whatsapp"></i> Share Win
                                        </button>
                                    <?php endif; ?>
                                </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <p class="text-muted text-center py-3 small">No winners yet. Be the first!</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Mobile Controls -->
    <div class="mobile-controls">
        <div class="container-fluid">
            <div class="row g-1">
                <div class="col">
                    <a href="index.php" class="btn btn-outline-dark w-100 d-flex flex-column align-items-center py-2">
                        <i class="fas fa-home mb-1"></i>
                        <span class="small">Home</span>
                    </a>
                </div>
                <div class="col">
                    <button class="btn btn-outline-info w-100 d-flex flex-column align-items-center py-2" onclick="$('#playerName').focus()">
                        <i class="fas fa-search mb-1"></i>
                        <span class="small">Search</span>
                    </button>
                </div>
                <div class="col">
                    <button class="btn btn-outline-success w-100 d-flex flex-column align-items-center py-2" onclick="speakCurrentNumber()">
                        <i class="fas fa-volume-up mb-1"></i>
                        <span class="small">Speak</span>
                    </button>
                </div>
                <div class="col">
                    <button class="btn btn-outline-warning w-100 d-flex flex-column align-items-center py-2" onclick="toggleFullscreen()">
                        <i class="fas fa-expand mb-1"></i>
                        <span class="small">Fullscreen</span>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Winner Announcement Popup -->
    <div class="winner-announcement" id="winnerPopup">
        <h3 class="mb-2">🎉 WINNER! 🎉</h3>
        <h5 id="winnerName"></h5>
        <p id="winnerPattern" class="mb-2"></p>
        <h4 class="text-success mb-3" id="winnerPrize"></h4>
        <p class="small mb-2" id="winnerMessage">Prize auto-claimed and shown to host!</p>
        <button class="btn btn-dark w-100 py-2" onclick="closeWinnerPopup()">
            <i class="fas fa-times me-2"></i>Close
        </button>
    </div>

    <!-- Pattern Claim Announcement -->
    <div class="winner-announcement" id="patternClaimPopup" style="display: none; background: linear-gradient(135deg, #17a2b8, #20c997);">
        <h3 class="mb-2">📣 PATTERN CLAIMED 📣</h3>
        <h5 id="claimedPatternName"></h5>
        <p class="mb-2" id="claimedPatternTicket"></p>
        <h4 class="text-warning mb-3" id="claimedPatternPrize"></h4>
        <p class="small mb-2" id="claimedPatternMessage">This pattern is now closed!</p>
        <button class="btn btn-dark w-100 py-2" onclick="closePatternClaimPopup()">
            <i class="fas fa-times me-2"></i>Close
        </button>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Game variables
        const gameCode = '<?php echo $game_code; ?>';
        const gameId = <?php echo $game['id']; ?>;
        const gameName = '<?php echo addslashes($game['game_name']); ?>';
        const patternsEnabled = <?php echo json_encode($patterns_enabled); ?>;
        const patternPrizes = <?php echo json_encode($pattern_prizes); ?>;
        const gameEnded = <?php echo $full_house_claimed ? 'true' : 'false'; ?>;
        
        let tickets = {}; // Object to store loaded tickets: {ticketCode: {data}}
        let activeTicketCode = null; // Currently active ticket for pattern checking
        let calledNumbers = <?php echo json_encode($called_numbers); ?>;
        let lastAnnouncedNumber = null;
        let autoVoiceEnabled = true;
        let autoClaimEnabled = true;
        let voiceSpeed = 1;
        let callSpeed = <?php echo $auto_call_delay; ?>;
        let autoCallInterval = null;
        let autoClaimInProgress = false;
        let currentWinnerData = null;
        let claimedPatterns = {};
        let playerTicketsCache = {}; // Cache for player tickets
        
        // Initialize
        $(document).ready(function() {
            // Set initial values
            autoVoiceEnabled = $('#autoVoice').is(':checked');
            autoClaimEnabled = $('#autoClaim').is(':checked');
            voiceSpeed = parseFloat($('#voiceSpeed').val());
            callSpeed = parseInt($('#callSpeed').val());
            
            // Show mobile controls on mobile
            if(window.innerWidth <= 768) {
                $('.mobile-controls').show();
            }
            
            // If game ended, show overlay
            if(gameEnded) {
                $('#gameEndedOverlay').show();
                return;
            }
            
            // Start auto update and ping
            updateGameState();
            setInterval(updateGameState, 3000);
            setInterval(sendPing, 30000); // Ping every 30 seconds
            
            // Check for winners announcements
            checkWinnerAnnouncements();
            setInterval(checkWinnerAnnouncements, 5000);
            
            // Check for claimed patterns
            checkClaimedPatterns();
            setInterval(checkClaimedPatterns, 5000);
            
            // Event listeners
            $('#autoVoice').change(function() {
                autoVoiceEnabled = $(this).is(':checked');
            });
            
            $('#autoClaim').change(function() {
                autoClaimEnabled = $(this).is(':checked');
            });
            
            $('#voiceSpeed').change(function() {
                voiceSpeed = parseFloat($(this).val());
            });
            
            $('#callSpeed').change(function() {
                callSpeed = parseInt($(this).val());
                updateAutoCallSpeed();
            });
            
            // Enter key for player name
            $('#playerName').keypress(function(e) {
                if(e.which == 13) searchPlayer();
            });
            
            // Adjust UI on window resize
            $(window).resize(function() {
                if(window.innerWidth <= 768) {
                    $('.mobile-controls').show();
                } else {
                    $('.mobile-controls').hide();
                }
            });
        });
        
        // Search tickets by player name
        function searchPlayer() {
            const playerName = $('#playerName').val().trim();
            if(!playerName) {
                alert('Please enter player name');
                return;
            }
            
            // Clear previous results
            $('#playerSearchResults').html('');
            
            // Check cache first
            if(playerTicketsCache[playerName]) {
                displayPlayerSearchResults(playerName, playerTicketsCache[playerName]);
                return;
            }
            
            // Show loading
            $('#playerSearchResults').html('<div class="text-center py-3"><i class="fas fa-spinner fa-spin me-2"></i>Searching...</div>');
            $('#playerSearchResults').removeClass('d-none');
            
            $.ajax({
                url: 'api.php',
                method: 'POST',
                data: { 
                    action: 'get_tickets_by_player_name',
                    player_name: playerName,
                    game_code: gameCode
                },
                success: function(response) {
                    if(response.success && response.tickets && response.tickets.length > 0) {
                        // Cache the results
                        playerTicketsCache[playerName] = response.tickets;
                        displayPlayerSearchResults(playerName, response.tickets);
                        speak(`Found ${response.tickets.length} tickets for ${playerName}`);
                    } else {
                        $('#playerSearchResults').html('<div class="text-center py-3 text-muted">No tickets found for this player.</div>');
                        speak(`No tickets found for ${playerName}`);
                    }
                },
                error: function() {
                    $('#playerSearchResults').html('<div class="text-center py-3 text-danger">Error searching for player tickets.</div>');
                }
            });
        }
        
        // Display player search results
        function displayPlayerSearchResults(playerName, playerTickets) {
            let html = '';
            
            playerTickets.forEach((ticket, index) => {
                const isSelected = tickets[ticket.ticket_code] ? 'selected' : '';
                html += `
                    <div class="player-search-item ${isSelected}" onclick="loadTicket('${ticket.ticket_code}', '${playerName}', ${index})">
                        <div class="player-info">
                            <div>
                                <strong class="ticket-code">${ticket.ticket_code}</strong>
                                <br>
                                <small>Player: ${playerName}</small>
                            </div>
                            ${ticket.is_claimed ? '<span class="badge bg-warning">🏆 Won</span>' : ''}
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <small class="text-muted">Click to load ticket</small>
                            <span class="ticket-count">Ticket ${index + 1}</span>
                        </div>
                    </div>
                `;
            });
            
            $('#playerSearchResults').html(html);
            $('#playerSearchResults').removeClass('d-none');
        }
        
        // Load ticket from search results
        function loadTicket(ticketCode, playerName, index) {
            // Clear previous selection
            $('.player-search-item').removeClass('selected');
            // Mark this item as selected
            $(`.player-search-item`).eq(index).addClass('selected');
            
            // Check if ticket already loaded
            if(tickets[ticketCode]) {
                // Ticket already loaded, just make it active
                setActiveTicket(ticketCode);
                speak(`Ticket ${ticketCode} already loaded`);
                return;
            }
            
            // Get ticket data from cache
            const playerTickets = playerTicketsCache[playerName];
            if(!playerTickets || !playerTickets[index]) return;
            
            const ticketData = playerTickets[index];
            
            // Add to tickets object
            tickets[ticketCode] = {
                numbers: ticketData.numbers,
                cornerIndices: [],
                corners: [],
                completedPatterns: {},
                claimedPatterns: {},
                playerName: playerName,
                isClaimed: ticketData.is_claimed || false
            };
            
            // Calculate corners for this ticket
            calculateCorners(ticketCode);
            
            // Update tickets display
            updateTicketsDisplay();
            
            // Set as active ticket
            setActiveTicket(ticketCode);
            
            // Enable claim button
            $('#claimAllBtn').prop('disabled', false);
            
            // Update pattern status
            $('#patternStatus').text(`Checking patterns for ${ticketCode}`);
            
            // Speak confirmation
            speak(`Loaded ticket ${ticketCode} for ${playerName}`);
            
            // Check patterns for this ticket
            checkPatterns();
        }
        
        // Calculate corners based on first and last numbers in first and last rows
        function calculateCorners(ticketCode) {
            const ticket = tickets[ticketCode];
            if(!ticket || !ticket.numbers || ticket.numbers.length !== 27) return;
            
            const cornerIndices = [];
            const corners = [];
            
            // Find first row corners (row 0)
            let firstRowStartCol = -1;
            let firstRowEndCol = -1;
            
            for(let col = 0; col < 9; col++) {
                const index = 0 * 9 + col;
                if(ticket.numbers[index] > 0) {
                    firstRowStartCol = col;
                    break;
                }
            }
            
            for(let col = 8; col >= 0; col--) {
                const index = 0 * 9 + col;
                if(ticket.numbers[index] > 0) {
                    firstRowEndCol = col;
                    break;
                }
            }
            
            // Find last row corners (row 2)
            let lastRowStartCol = -1;
            let lastRowEndCol = -1;
            
            for(let col = 0; col < 9; col++) {
                const index = 2 * 9 + col;
                if(ticket.numbers[index] > 0) {
                    lastRowStartCol = col;
                    break;
                }
            }
            
            for(let col = 8; col >= 0; col--) {
                const index = 2 * 9 + col;
                if(ticket.numbers[index] > 0) {
                    lastRowEndCol = col;
                    break;
                }
            }
            
            if(firstRowStartCol !== -1) {
                const index = 0 * 9 + firstRowStartCol;
                cornerIndices.push(index);
                corners.push(ticket.numbers[index]);
            }
            
            if(firstRowEndCol !== -1 && firstRowEndCol !== firstRowStartCol) {
                const index = 0 * 9 + firstRowEndCol;
                cornerIndices.push(index);
                corners.push(ticket.numbers[index]);
            }
            
            if(lastRowStartCol !== -1) {
                const index = 2 * 9 + lastRowStartCol;
                cornerIndices.push(index);
                corners.push(ticket.numbers[index]);
            }
            
            if(lastRowEndCol !== -1 && lastRowEndCol !== lastRowStartCol) {
                const index = 2 * 9 + lastRowEndCol;
                cornerIndices.push(index);
                corners.push(ticket.numbers[index]);
            }
            
            ticket.cornerIndices = cornerIndices;
            ticket.corners = corners;
        }
        
        // Update tickets display
        function updateTicketsDisplay() {
            const ticketKeys = Object.keys(tickets);
            
            if(ticketKeys.length === 0) {
                $('#noTicketsMessage').show();
                $('#ticketsContainer').html('');
                return;
            }
            
            $('#noTicketsMessage').hide();
            let html = '';
            
            ticketKeys.forEach(ticketCode => {
                const ticket = tickets[ticketCode];
                const isActive = ticketCode === activeTicketCode;
                
                html += `
                    <div class="ticket-display-card ${isActive ? 'active' : ''}" id="ticket-card-${ticketCode}">
                        <div class="ticket-header">
                            <div>
                                <span class="ticket-code">${ticketCode}</span>
                                <span class="badge bg-secondary ms-2">${ticket.playerName}</span>
                                ${ticket.isClaimed ? '<span class="badge bg-warning ms-2">🏆 Winner</span>' : ''}
                            </div>
                            <div>
                                <button class="btn btn-sm btn-outline-primary" onclick="setActiveTicket('${ticketCode}')" title="Check Patterns">
                                    <i class="fas fa-crosshairs"></i>
                                </button>
                                <button class="btn btn-sm btn-outline-danger ms-1" onclick="removeTicket('${ticketCode}')" title="Remove Ticket">
                                    <i class="fas fa-times"></i>
                                </button>
                            </div>
                        </div>
                        <div class="ticket-display" id="ticket-display-${ticketCode}">
                            ${generateTicketGrid(ticket)}
                        </div>
                    </div>
                `;
            });
            
            $('#ticketsContainer').html(html);
        }
        
        // Generate ticket grid HTML
        function generateTicketGrid(ticket) {
            if(!ticket || !ticket.numbers || ticket.numbers.length !== 27) return '';
            
            let html = '<div class="ticket-grid">';
            
            // Create 3x9 grid
            for(let row = 0; row < 3; row++) {
                for(let col = 0; col < 9; col++) {
                    const index = row * 9 + col;
                    const number = ticket.numbers[index];
                    const hasNumber = number > 0;
                    const isMarked = hasNumber && calledNumbers.includes(number);
                    const isCorner = ticket.cornerIndices.includes(index);
                    
                    html += `<div class="ticket-cell ${hasNumber ? 'has-number' : ''} ${isMarked ? 'marked' : ''} ${isCorner ? 'corner' : ''}" 
                             data-number="${number}" data-index="${index}">
                             ${hasNumber ? number : ''}</div>`;
                }
            }
            
            html += '</div>';
            return html;
        }
        
        // Set active ticket
        function setActiveTicket(ticketCode) {
            if(!tickets[ticketCode]) return;
            
            activeTicketCode = ticketCode;
            
            // Update UI
            $('.ticket-display-card').removeClass('active');
            $(`#ticket-card-${ticketCode}`).addClass('active');
            
            // Check patterns for this ticket
            checkPatterns();
            
            speak(`Now checking patterns for ticket ${ticketCode}`);
        }
        
        // Remove ticket
        function removeTicket(ticketCode) {
            if(confirm(`Remove ticket ${ticketCode}?`)) {
                delete tickets[ticketCode];
                
                if(activeTicketCode === ticketCode) {
                    activeTicketCode = Object.keys(tickets)[0] || null;
                }
                
                updateTicketsDisplay();
                
                if(activeTicketCode) {
                    setActiveTicket(activeTicketCode);
                } else {
                    $('#noTicketsMessage').show();
                    $('#claimAllBtn').prop('disabled', true);
                    $('#patternStatus').text('Add player tickets to check patterns');
                }
                
                // Update search results selection
                $(`.player-search-item`).each(function() {
                    if($(this).find('.ticket-code').text() === ticketCode) {
                        $(this).removeClass('selected');
                    }
                });
                
                speak(`Removed ticket ${ticketCode}`);
            }
        }
        
        // Clear search
        function clearSearch() {
            $('#playerName').val('');
            $('#playerSearchResults').addClass('d-none');
            $('#playerSearchResults').html('');
        }
        
        // Check for claimed patterns
        function checkClaimedPatterns() {
            $.ajax({
                url: 'api.php',
                method: 'GET',
                data: { action: 'get_claimed_patterns', game_id: gameId },
                success: function(response) {
                    if(response.success && response.patterns) {
                        response.patterns.forEach(pattern => {
                            if(!claimedPatterns[pattern]) {
                                claimedPatterns[pattern] = true;
                                markPatternAsClaimed(pattern);
                            }
                        });
                    }
                }
            });
        }
        
        // Mark pattern as claimed in UI
        function markPatternAsClaimed(pattern) {
            const $badge = $('#pattern-' + pattern);
            $badge.removeClass('completed won');
            $badge.addClass('claimed-gone');
            
            const patternNames = {
                'top_line': 'Top Line',
                'bottom_line': 'Bottom Line',
                'corners': 'Corners',
                'middle_line': 'Middle Line',
                'full_house': 'Full House'
            };
            
            // Announce pattern claimed
            announcePatternClaimed(patternNames[pattern] || pattern);
        }
        
        // Announce pattern claimed
        function announcePatternClaimed(patternName) {
            speak(`${patternName} pattern has been claimed by another player! This pattern is now closed.`);
            
            // Show visual notification
            $('#claimedPatternName').text(patternName);
            $('#claimedPatternMessage').text('This pattern has been claimed and is now closed!');
            $('#patternClaimPopup').fadeIn();
            
            setTimeout(() => {
                $('#patternClaimPopup').fadeOut();
            }, 5000);
        }
        
        // Claim all winning patterns
        function claimAllWinningPatterns() {
            if(!activeTicketCode) {
                alert('Please select a ticket first!');
                return;
            }
            
            const ticket = tickets[activeTicketCode];
            const patternsToClaim = [];
            
            // Check each pattern
            Object.keys(patternsEnabled).forEach(pattern => {
                if(patternsEnabled[pattern] && !ticket.claimedPatterns?.[pattern] && !claimedPatterns[pattern]) {
                    let completed = false;
                    
                    switch(pattern) {
                        case 'top_line':
                            completed = checkLine(0, ticket);
                            break;
                        case 'bottom_line':
                            completed = checkLine(2, ticket);
                            break;
                        case 'middle_line':
                            completed = checkLine(1, ticket);
                            break;
                        case 'corners':
                            completed = checkCorners(ticket);
                            break;
                        case 'full_house':
                            completed = checkFullHouse(ticket);
                            break;
                    }
                    
                    if(completed) {
                        patternsToClaim.push(pattern);
                    }
                }
            });
            
            if(patternsToClaim.length === 0) {
                alert('No winning patterns to claim yet!');
                return;
            }
            
            const patternNames = getPatternNames();
            const claimList = patternsToClaim.map(p => 
                patternNames[p] + ' (₹' + (patternPrizes[p] || 0) + ')'
            ).join('\n');
            
            if(confirm(`Claim ${patternsToClaim.length} pattern(s)?\n\n${claimList}`)) {
                patternsToClaim.forEach(pattern => {
                    const prize = patternPrizes[pattern] || 0;
                    if(prize > 0) {
                        claimPrize(activeTicketCode, pattern, prize, patternNames[pattern]);
                    }
                });
            }
        }
        
        function getPatternNames() {
            return {
                'top_line': 'Top Line',
                'bottom_line': 'Bottom Line',
                'corners': 'Corners',
                'middle_line': 'Middle Line',
                'full_house': 'Full House'
            };
        }
        
        // Keep page active with ping
        function sendPing() {
            $.ajax({
                url: 'api.php',
                method: 'POST',
                data: { action: 'ping', game_code: gameCode },
                success: function() {
                    $('#onlineStatus').html('🟢 Online');
                },
                error: function() {
                    $('#onlineStatus').html('🔴 Offline');
                }
            });
        }
        
        // Share winner on WhatsApp
        function shareWinnerOnWhatsApp(playerName, patternType, ticketCode, prizeAmount) {
            const gameLink = window.location.href;
            const patternNames = getPatternNames();
            
            const patternName = patternNames[patternType] || patternType;
            
            const message = `🎉 ${playerName} WON in Tambola! 🎉\n\n` +
                          `Game: ${gameName}\n` +
                          `Pattern: ${patternName}\n` +
                          `Ticket: ${ticketCode}\n` +
                          `Prize: ₹${prizeAmount}\n` +
                          `Game Code: ${gameCode}\n\n` +
                          `Join the fun: ${gameLink}`;
            
            const encodedMessage = encodeURIComponent(message);
            const whatsappUrl = `https://wa.me/?text=${encodedMessage}`;
            window.open(whatsappUrl, '_blank');
        }
        
        // Voice functions
        function speak(text) {
            if(!autoVoiceEnabled) return;
            
            if('speechSynthesis' in window) {
                speechSynthesis.cancel();
                const utterance = new SpeechSynthesisUtterance(text);
                utterance.rate = voiceSpeed;
                utterance.volume = 1;
                utterance.pitch = 1;
                
                const voices = speechSynthesis.getVoices();
                const femaleVoice = voices.find(v => v.lang.startsWith('en') && v.name.includes('Female'));
                if(femaleVoice) utterance.voice = femaleVoice;
                
                speechSynthesis.speak(utterance);
            }
        }
        
        function speakCurrentNumber() {
            const num = $('#currentNumber').text();
            if(num && num !== '--') {
                speak(`Number ${num}`);
            }
        }
        
        function testVoice() {
            speak("Welcome to Tambola!");
        }
        
        // Game state update
        function updateGameState() {
            if(gameEnded) return;
            
            $.ajax({
                url: 'api.php',
                method: 'GET',
                data: { action: 'get_game_state', code: gameCode },
                success: function(response) {
                    if(response.current_number && response.current_number !== '--') {
                        $('#currentNumber').text(response.current_number);
                        
                        if(autoVoiceEnabled && lastAnnouncedNumber !== response.current_number) {
                            speak(`Number ${response.current_number}`);
                            lastAnnouncedNumber = response.current_number;
                        }
                    }
                    
                    if(response.called_numbers) {
                        calledNumbers = response.called_numbers;
                        updateNumberBoard();
                        updateCalledNumbersList();
                        
                        // Update all displayed tickets
                        Object.keys(tickets).forEach(ticketCode => {
                            updateTicketDisplayMarkings(ticketCode);
                        });
                        
                        checkPatterns();
                    }
                    
                    // Check if game ended
                    if(response.game_status === 'ended') {
                        location.reload(); // Reload to show game ended overlay
                    }
                }
            });
        }
        
        // Update number board
        function updateNumberBoard() {
            for(let i = 1; i <= 90; i++) {
                const $cell = $('#num-' + i);
                if(calledNumbers.includes(i)) {
                    $cell.addClass('called');
                } else {
                    $cell.removeClass('called');
                }
            }
        }
        
        // Update called numbers list
        function updateCalledNumbersList() {
            const recent = calledNumbers.slice(-12);
            let html = '';
            recent.forEach(num => {
                html += `<span class="badge bg-success me-1 mb-1">${num}</span>`;
            });
            $('#calledNumbersList').html(html);
        }
        
        // Update ticket display markings
        function updateTicketDisplayMarkings(ticketCode) {
            const ticket = tickets[ticketCode];
            if(!ticket) return;
            
            $(`#ticket-display-${ticketCode} .ticket-cell[data-index]`).each(function() {
                const index = parseInt($(this).data('index'));
                const number = ticket.numbers[index];
                if(number > 0 && calledNumbers.includes(number)) {
                    $(this).addClass('marked');
                } else {
                    $(this).removeClass('marked');
                }
            });
        }
        
        // Check winning patterns for active ticket
        function checkPatterns() {
            if(!activeTicketCode || autoClaimInProgress) return;
            
            const ticket = tickets[activeTicketCode];
            if(!ticket || !ticket.numbers || ticket.numbers.length !== 27) return;
            
            const results = {};
            
            Object.keys(patternsEnabled).forEach(pattern => {
                if(patternsEnabled[pattern] && !claimedPatterns[pattern]) {
                    switch(pattern) {
                        case 'top_line':
                            results[pattern] = checkLine(0, ticket);
                            break;
                        case 'bottom_line':
                            results[pattern] = checkLine(2, ticket);
                            break;
                        case 'middle_line':
                            results[pattern] = checkLine(1, ticket);
                            break;
                        case 'corners':
                            results[pattern] = checkCorners(ticket);
                            break;
                        case 'full_house':
                            results[pattern] = checkFullHouse(ticket);
                            break;
                    }
                }
            });
            
            Object.keys(results).forEach(pattern => {
                const $badge = $('#pattern-' + pattern);
                const wasCompleted = ticket.completedPatterns[pattern] || false;
                const isCompleted = results[pattern];
                
                if(isCompleted && !wasCompleted) {
                    // Pattern just completed
                    autoClaimInProgress = true;
                    ticket.completedPatterns[pattern] = true;
                    
                    // Only mark as completed if not auto-claiming
                    if(!autoClaimEnabled) {
                        $badge.addClass('completed');
                    }
                    
                    const prize = patternPrizes[pattern] || 0;
                    const patternNames = getPatternNames();
                    const patternName = patternNames[pattern] || pattern;
                    
                    // Auto claim if enabled
                    if(autoClaimEnabled && prize > 0) {
                        claimPrize(activeTicketCode, pattern, prize, patternName);
                    }
                    
                    setTimeout(() => { autoClaimInProgress = false; }, 1000);
                } else if(isCompleted && !autoClaimEnabled) {
                    $badge.addClass('completed');
                } else if(!isCompleted) {
                    $badge.removeClass('completed');
                }
            });
            
            const completed = Object.values(results).filter(Boolean).length;
            const total = Object.keys(patternsEnabled).filter(p => patternsEnabled[p] && !claimedPatterns[p]).length;
            $('#patternStatus').text(`Completed ${completed} of ${total} patterns`);
        }
        
        function checkLine(row, ticket) {
            for(let col = 0; col < 9; col++) {
                const index = row * 9 + col;
                const number = ticket.numbers[index];
                if(number > 0 && !calledNumbers.includes(number)) {
                    return false;
                }
            }
            return true;
        }
        
        function checkCorners(ticket) {
            return ticket.corners.every(number => calledNumbers.includes(number));
        }
        
        function checkFullHouse(ticket) {
            return ticket.numbers.every(num => num === 0 || calledNumbers.includes(num));
        }
        
        // Auto claim prize and show to host
        function claimPrize(ticketCode, pattern, prize, patternName) {
            const ticket = tickets[ticketCode];
            if(!ticket || claimedPatterns[pattern]) return;
            
            $.ajax({
                url: 'api.php',
                method: 'POST',
                data: {
                    action: 'claim_prize',
                    game_code: gameCode,
                    ticket_code: ticketCode,
                    pattern: pattern,
                    prize: prize,
                    player_name: ticket.playerName
                },
                success: function(response) {
                    if(response.success) {
                        // Mark pattern as claimed
                        claimedPatterns[pattern] = true;
                        if(ticket.claimedPatterns) {
                            ticket.claimedPatterns[pattern] = true;
                        }
                        
                        // Store winner data for WhatsApp sharing
                        currentWinnerData = {
                            player_name: ticket.playerName,
                            ticket_code: ticketCode,
                            pattern_type: pattern,
                            prize_amount: prize
                        };
                        
                        // Update UI
                        const $badge = $('#pattern-' + pattern);
                        $badge.removeClass('completed');
                        $badge.addClass('claimed');
                        
                        // Show winner announcement
                        showWinnerAnnouncement(currentWinnerData, true);
                        
                        // Announce pattern claimed
                        announcePatternClaimed(patternName);
                        
                        // If full house was claimed, end game
                        if(pattern === 'full_house') {
                            endGame();
                        }
                        
                        // Show notification
                        if(!autoClaimEnabled) {
                            alert(`✅ ${patternName} claimed successfully!`);
                        }
                    } else {
                        alert('Error: ' + response.error);
                    }
                },
                error: function() {
                    alert('Error claiming prize. Please try again.');
                }
            });
        }
        
        // End game when full house is claimed
        function endGame() {
            if(autoCallInterval) {
                clearInterval(autoCallInterval);
                autoCallInterval = null;
            }
            
            // Announce game end
            speak(`Game Over! Full House has been claimed! The game has ended. Thank you for playing ${gameName}!`);
            
            // Show game ended overlay after delay
            setTimeout(() => {
                location.reload();
            }, 5000);
        }
        
        // Check for winner announcements
        function checkWinnerAnnouncements() {
            $.ajax({
                url: 'api.php',
                method: 'GET',
                data: { action: 'get_first_winners', game_id: gameId },
                success: function(response) {
                    if(response.winners && response.winners.length > 0) {
                        updateWinnersList(response.winners);
                        
                        response.winners.forEach(winner => {
                            if(!window.seenWinners) window.seenWinners = [];
                            if(!window.seenWinners.includes(winner.id)) {
                                window.seenWinners.push(winner.id);
                                showWinnerAnnouncement(winner, false);
                                
                                // Mark pattern as claimed
                                claimedPatterns[winner.pattern_type] = true;
                                markPatternAsClaimed(winner.pattern_type);
                            }
                        });
                    }
                }
            });
        }
        
        function updateWinnersList(winners) {
            let html = '';
            if(winners.length === 0) {
                html = '<p class="text-muted text-center py-3 small">No winners yet. Be the first!</p>';
            } else {
                winners.forEach(winner => {
                    const patternNames = getPatternNames();
                    
                    html += `
                    <div class="winner-card" data-winner-id="${winner.id}">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="mb-1">🎉 ${winner.player_name}</h6>
                                <p class="mb-0 small">Ticket: <code>${winner.ticket_code}</code></p>
                            </div>
                            <div class="text-end">
                                <span class="badge bg-dark">${patternNames[winner.pattern_type]}</span>
                                <h5 class="mb-0 text-success">₹${parseInt(winner.prize_amount)}</h5>
                            </div>
                        </div>`;
                    
                    // Add WhatsApp share button only for Full House winners
                    if(winner.pattern_type === 'full_house') {
                        html += `
                        <button class="whatsapp-share-btn" onclick="shareWinnerOnWhatsApp(
                            '${winner.player_name.replace(/'/g, "\\'")}',
                            '${winner.pattern_type}',
                            '${winner.ticket_code}',
                            ${winner.prize_amount}
                        )">
                            <i class="fab fa-whatsapp"></i> Share Win
                        </button>`;
                    }
                    
                    html += `</div>`;
                });
            }
            $('#winnersList').html(html);
        }
        
        function showWinnerAnnouncement(winner, isAutoClaimed) {
            const patternNames = getPatternNames();
            
            $('#winnerName').text(winner.player_name);
            $('#winnerPattern').text(`Won ${patternNames[winner.pattern_type]} on ticket ${winner.ticket_code}`);
            $('#winnerPrize').text(`₹${parseInt(winner.prize_amount)}`);
            
            if(isAutoClaimed) {
                $('#winnerMessage').text('Prize claimed and shown to host!');
            } else {
                $('#winnerMessage').text('First winner for this pattern!');
            }
            
            $('#winnerPopup').fadeIn();
            
            // Announce winner with voice
            speak(`Congratulations to ${winner.player_name} for winning ${patternNames[winner.pattern_type]} with prize amount ${winner.prize_amount} rupees!`);
            
            // Auto close after 8 seconds
            setTimeout(closeWinnerPopup, 8000);
        }
        
        function closeWinnerPopup() {
            $('#winnerPopup').fadeOut();
            currentWinnerData = null;
        }
        
        function closePatternClaimPopup() {
            $('#patternClaimPopup').fadeOut();
        }
        
        // Auto-call system
        function updateAutoCallSpeed() {
            if(autoCallInterval) clearInterval(autoCallInterval);
            
            if(callSpeed > 0 && !gameEnded) {
                autoCallInterval = setInterval(function() {
                    if(calledNumbers.length < 90 && !claimedPatterns['full_house']) {
                        $.ajax({
                            url: 'api.php',
                            method: 'POST',
                            data: {
                                action: 'auto_call_number',
                                game_code: gameCode
                            }
                        });
                    } else {
                        clearInterval(autoCallInterval);
                    }
                }, callSpeed * 1000);
            }
        }
        
        function toggleFullscreen() {
            if(!document.fullscreenElement) {
                const elem = document.documentElement;
                if(elem.requestFullscreen) {
                    elem.requestFullscreen();
                } else if(elem.webkitRequestFullscreen) {
                    elem.webkitRequestFullscreen();
                } else if(elem.msRequestFullscreen) {
                    elem.msRequestFullscreen();
                }
            } else {
                if(document.exitFullscreen) {
                    document.exitFullscreen();
                } else if(document.webkitExitFullscreen) {
                    document.webkitExitFullscreen();
                } else if(document.msExitFullscreen) {
                    document.msExitFullscreen();
                }
            }
        }
        
        // Handle orientation change
        window.addEventListener('orientationchange', function() {
            setTimeout(function() {
                location.reload();
            }, 100);
        });
        
        // Add this function to hide the game ended overlay
function hideGameEndOverlay() {
    $('#gameEndedOverlay').hide();
    // Optional: You can also speak a message
    speak("You can continue viewing the game results.");
}
        
        
    </script>
</body>
</html>