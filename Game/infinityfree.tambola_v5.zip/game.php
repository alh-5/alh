<?php
require_once 'config.php';

$game_code = $_GET['code'] ?? '';
if(empty($game_code)) {
    header('Location: index.php');
    exit;
}

// Get game data
$stmt = $conn->prepare("SELECT * FROM games WHERE game_code = ?");
$stmt->bind_param("s", $game_code);
$stmt->execute();
$game_result = $stmt->get_result();
$game = $game_result->fetch_assoc();

if(!$game) {
    die("Game not found!");
}

$called_numbers = json_decode($game['called_numbers'] ?? '[]', true) ?: [];
$patterns_enabled = json_decode($game['patterns_enabled'] ?? '[]', true) ?: [];
$pattern_prizes = json_decode($game['pattern_prizes'] ?? '{}', true) ?: [];
$auto_call_delay = $game['auto_call_delay'] ?? 5;

// Get first winners for each pattern for this game
$winners_stmt = $conn->prepare("
    SELECT w1.* 
    FROM wins w1
    WHERE w1.game_id = ? 
    AND w1.claimed_at = (
        SELECT MIN(w2.claimed_at) 
        FROM wins w2 
        WHERE w2.game_id = w1.game_id 
        AND w2.pattern_type = w1.pattern_type
    )
    ORDER BY w1.claimed_at DESC
    LIMIT 5
");
$winners_stmt->bind_param("i", $game['id']);
$winners_stmt->execute();
$winners_result = $winners_stmt->get_result();

// Update last ping time to keep session alive
$_SESSION['last_ping'] = time();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?php echo $game['game_name']; ?> - DB Tambola</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #4b6cb7;
            --secondary: #182848;
            --accent: #ff5722;
        }
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            -webkit-text-size-adjust: 100%;
            -webkit-tap-highlight-color: transparent;
        }
        .game-container {
            max-width: 100%;
            margin: 0;
            padding: 8px;
            padding-bottom: 70px;
            overflow-x: hidden;
        }
        .current-number-display {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            border-radius: 15px;
            padding: 15px 10px;
            color: white;
            text-align: center;
            margin-bottom: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            width: 100%;
            overflow: hidden;
        }
        .current-number {
            font-size: 3.5rem;
            font-weight: bold;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
            color: #ffeb3b;
            animation: pulse 2s infinite;
            line-height: 1;
            word-break: break-word;
        }
        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.05); }
        }
        .game-card {
            background: white;
            border-radius: 12px;
            padding: 15px;
            margin-bottom: 15px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.08);
            overflow: hidden;
        }
        .number-grid {
            display: grid;
            grid-template-columns: repeat(10, 1fr);
            gap: 5px;
            margin-top: 10px;
        }
        .number-cell {
            aspect-ratio: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            font-weight: bold;
            font-size: 0.9rem;
            background: white;
            transition: all 0.3s;
            min-width: 0;
        }
        .number-cell.called {
            background: linear-gradient(135deg, #4CAF50, #2E7D32);
            color: white;
            border-color: #388E3C;
            transform: scale(1.05);
        }
        .ticket-grid {
            display: grid;
            grid-template-columns: repeat(9, 1fr);
            gap: 3px;
            margin: 8px 0;
        }
        .ticket-cell {
            aspect-ratio: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-weight: bold;
            background: #f8f9fa;
            position: relative;
            font-size: 0.8rem;
            min-width: 0;
        }
        .ticket-cell.has-number {
            background: white;
        }
        .ticket-cell.marked {
            background: #FFD700;
            color: #000;
            border-color: #FFC107;
        }
        .ticket-cell.corner {
            background: #ffebee;
            border: 2px solid #FF5722 !important;
        }
        .ticket-cell.corner.marked {
            background: linear-gradient(135deg, #FF9800, #FF5722);
            color: white;
            border-color: #F57C00 !important;
        }
        .pattern-badge {
            display: inline-block;
            padding: 6px 12px;
            margin: 3px;
            border-radius: 15px;
            font-size: 0.8rem;
            font-weight: 600;
            background: #e9ecef;
            color: #495057;
            transition: all 0.3s;
            position: relative;
        }
        .pattern-badge.completed {
            background: #28a745;
            color: white;
            animation: success 1s;
        }
        .pattern-badge.won {
            background: #ffc107;
            color: #000;
            animation: winner 2s infinite;
        }
        @keyframes success {
            0% { transform: scale(1); }
            50% { transform: scale(1.1); }
            100% { transform: scale(1); }
        }
        @keyframes winner {
            0%, 100% { box-shadow: 0 0 8px #ffc107; }
            50% { box-shadow: 0 0 15px #ff9800; }
        }
        .winner-card {
            background: linear-gradient(135deg, #ffd700, #ff9800);
            border-radius: 8px;
            padding: 10px;
            margin: 8px 0;
            animation: slideIn 0.5s;
        }
        @keyframes slideIn {
            from { transform: translateX(-100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        .mobile-controls {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: white;
            padding: 12px 8px;
            box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
            z-index: 1000;
            display: none;
        }
        .voice-control-slider {
            width: 100%;
            margin: 8px 0;
        }
        .winner-announcement {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: linear-gradient(135deg, #ffd700, #ff9800);
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 15px 30px rgba(0,0,0,0.3);
            z-index: 2000;
            display: none;
            text-align: center;
            animation: popup 0.5s;
            width: 90%;
            max-width: 400px;
        }
        .whatsapp-share-btn {
            background: #25D366;
            color: white;
            border: none;
            padding: 6px 12px;
            border-radius: 8px;
            font-weight: bold;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            transition: all 0.3s;
            font-size: 0.8rem;
            margin: 5px auto 0;
            width: auto;
        }
        .whatsapp-share-btn:hover {
            background: #128C7E;
            transform: scale(1.05);
        }
        .whatsapp-share-btn i {
            font-size: 0.9rem;
        }
        .auto-claim-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: #28a745;
            color: white;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.7rem;
        }
        @keyframes popup {
            0% { transform: translate(-50%, -50%) scale(0.5); opacity: 0; }
            100% { transform: translate(-50%, -50%) scale(1); opacity: 1; }
        }
        
        /* Extra small devices (phones, 360px and down) */
        @media (max-width: 360px) {
            .current-number {
                font-size: 2.8rem;
            }
            .game-card {
                padding: 12px;
            }
            .number-cell {
                font-size: 0.8rem;
                padding: 2px;
            }
            .ticket-cell {
                font-size: 0.7rem;
            }
            .pattern-badge {
                padding: 5px 10px;
                font-size: 0.75rem;
            }
            .whatsapp-share-btn {
                padding: 5px 10px;
                font-size: 0.75rem;
            }
        }
        
        /* Small devices (phones, 600px and down) */
        @media (max-width: 600px) {
            .current-number {
                font-size: 3rem;
            }
            .game-container {
                padding: 8px 5px;
            }
            .mobile-controls {
                display: flex !important;
            }
            .number-cell {
                font-size: 0.85rem;
                padding: 3px;
            }
            .ticket-cell {
                font-size: 0.75rem;
            }
            .game-card h5 {
                font-size: 1rem;
            }
            .winner-card h6 {
                font-size: 0.9rem;
            }
        }
        
        /* Medium devices (tablets, 768px and down) */
        @media (max-width: 768px) {
            .game-container {
                padding: 10px 8px;
            }
            .row {
                margin: 0 -5px;
            }
            .col-lg-8, .col-lg-4 {
                padding: 0 5px;
            }
        }
        
        /* Large devices (desktops, 992px and up) */
        @media (min-width: 992px) {
            .game-container {
                max-width: 1200px;
                margin: 0 auto;
                padding: 15px;
            }
        }
        
        /* Prevent zoom on input focus in mobile */
        input, select, textarea {
            font-size: 16px !important;
        }
        
        /* Better touch targets */
        button, .btn, .ticket-badge, .pattern-badge {
            min-height: 44px;
            min-width: 44px;
        }
        
        /* Improve scrolling */
        .game-container {
            -webkit-overflow-scrolling: touch;
        }
    </style>
</head>
<body>
    <div class="game-container">
        <!-- Game Header -->
        <div class="current-number-display">
            <div class="row align-items-center g-2">
                <div class="col-4 text-start">
                    <h6 class="mb-1">
                        <i class="fas fa-gamepad me-1"></i><?php echo htmlspecialchars($game['game_name']); ?>
                    </h6>
                    <p class="mb-0 small">Code: <strong><?php echo $game_code; ?></strong></p>
                    <p class="mb-0 small" id="onlineStatus">🟢 Online</p>
                </div>
                <div class="col-4 text-center">
                    <div class="current-number" id="currentNumber">
                        <?php echo $game['current_number'] ?: '--'; ?>
                    </div>
                    <p class="mt-1 mb-0 small">Current Number</p>
                </div>
                <div class="col-4 text-end">
                    <div class="btn-group btn-group-sm">
                        <a href="index.php" class="btn btn-light">
                            <i class="fas fa-home"></i>
                        </a>
                        <button class="btn btn-light" onclick="toggleFullscreen()">
                            <i class="fas fa-expand"></i>
                        </button>
                        <?php if($game['status'] == 'started'): ?>
                            <button class="btn btn-success" onclick="speakCurrentNumber()">
                                <i class="fas fa-volume-up"></i>
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="row g-2">
            <!-- Left Column -->
            <div class="col-lg-8">
                <!-- Number Board -->
                <div class="game-card">
                    <h5 class="mb-2"><i class="fas fa-dice me-2"></i>Numbers (1-90)</h5>
                    <div id="calledNumbersList" class="mb-2">
                        <?php foreach(array_slice($called_numbers, -12) as $num): ?>
                            <span class="badge bg-success me-1 mb-1 fs-6"><?php echo $num; ?></span>
                        <?php endforeach; ?>
                    </div>
                    
                    <div class="number-grid">
                        <?php for($i = 1; $i <= 90; $i++): ?>
                            <div class="number-cell <?php echo in_array($i, $called_numbers) ? 'called' : ''; ?>" 
                                 id="num-<?php echo $i; ?>">
                                <?php echo $i; ?>
                            </div>
                        <?php endfor; ?>
                    </div>
                </div>

                <!-- First Winners Only -->
                <div class="game-card">
                    <h5 class="mb-2"><i class="fas fa-trophy me-2"></i>First Winners</h5>
                    <div id="winnersList">
                        <?php if($winners_result->num_rows > 0): ?>
                            <?php while($winner = $winners_result->fetch_assoc()): 
                                $pattern_names = [
                                    'top_line' => 'Top Line',
                                    'bottom_line' => 'Bottom Line',
                                    'corners' => 'Corners',
                                    'middle_line' => 'Middle Line',
                                    'full_house' => 'Full House'
                                ];
                            ?>
                                <div class="winner-card" data-winner-id="<?php echo $winner['id']; ?>">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div>
                                            <h6 class="mb-1">🎉 <?php echo $winner['player_name']; ?></h6>
                                            <p class="mb-0 small">Ticket: <code><?php echo $winner['ticket_code']; ?></code></p>
                                        </div>
                                        <div class="text-end">
                                            <span class="badge bg-dark"><?php echo $pattern_names[$winner['pattern_type']]; ?></span>
                                            <h5 class="mb-0 text-success">₹<?php echo number_format($winner['prize_amount'], 0); ?></h5>
                                        </div>
                                    </div>
                                    <?php if($winner['pattern_type'] == 'full_house'): ?>
                                        <button class="whatsapp-share-btn" onclick="shareWinnerOnWhatsApp(
                                            '<?php echo addslashes($winner['player_name']); ?>',
                                            '<?php echo $winner['pattern_type']; ?>',
                                            '<?php echo $winner['ticket_code']; ?>',
                                            <?php echo $winner['prize_amount']; ?>
                                        )">
                                            <i class="fab fa-whatsapp"></i> Share Win
                                        </button>
                                    <?php endif; ?>
                                </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <p class="text-muted text-center py-3 small">No winners yet. Be the first!</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Right Column -->
            <div class="col-lg-4">
                <!-- Tickets Management -->
                <div class="game-card mb-3">
                    <h5 class="mb-2"><i class="fas fa-ticket-alt me-2"></i>Your Tickets</h5>
                    <div class="mb-2">
                        <div class="input-group input-group-sm">
                            <input type="text" id="ticketCode" class="form-control" 
                                   placeholder="Enter ticket code" value="<?php echo $_GET['ticket'] ?? ''; ?>">
                            <button class="btn btn-primary" onclick="addTicket()">
                                <i class="fas fa-plus"></i>
                            </button>
                        </div>
                    </div>
                    <div id="ticketsList" class="mb-2">
                        <!-- Active tickets will appear here -->
                    </div>
                    <div id="ticketDisplay">
                        <p class="text-muted text-center py-3 small">Add your ticket codes to display</p>
                    </div>
                </div>

                <!-- Patterns with Auto Claim -->
                <div class="game-card mb-3">
                    <h5 class="mb-2"><i class="fas fa-shapes me-2"></i>Winning Patterns</h5>
                    <div class="mb-2">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="autoClaim" checked>
                            <label class="form-check-label" for="autoClaim">Auto Claim & Show to Host</label>
                        </div>
                    </div>
                    <div id="patternsContainer">
                        <?php foreach($patterns_enabled as $pattern => $enabled): 
                            if($enabled): 
                                $names = [
                                    'top_line' => 'Top Line',
                                    'bottom_line' => 'Bottom Line', 
                                    'corners' => 'Corners',
                                    'middle_line' => 'Middle Line',
                                    'full_house' => 'Full House'
                                ];
                                $prize = $pattern_prizes[$pattern] ?? 0;
                        ?>
                            <div class="pattern-badge" id="pattern-<?php echo $pattern; ?>" style="position: relative;">
                                <?php echo $names[$pattern] ?? ucfirst($pattern); ?>
                                <?php if($prize > 0): ?>
                                    <small class="ms-1">(₹<?php echo $prize; ?>)</small>
                                <?php endif; ?>
                            </div>
                        <?php endif; endforeach; ?>
                    </div>
                    <div id="patternStatus" class="mt-2 small text-muted">
                        Add tickets to check patterns
                    </div>
                </div>

                <!-- Voice Controls -->
                <div class="game-card">
                    <h5 class="mb-2"><i class="fas fa-volume-up me-2"></i>Voice Settings</h5>
                    <div class="mb-2">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="autoVoice" checked>
                            <label class="form-check-label" for="autoVoice">Auto Announce Numbers</label>
                        </div>
                    </div>
                    <div class="mb-2">
                        <label class="form-label small">Call Speed</label>
                        <input type="range" class="form-range voice-control-slider" id="callSpeed" 
                               min="1" max="30" value="<?php echo $auto_call_delay; ?>">
                        <div class="d-flex justify-content-between small">
                            <span>Fast</span>
                            <span>Normal</span>
                            <span>Slow</span>
                        </div>
                    </div>
                    <div class="mb-2">
                        <label class="form-label small">Voice Speed</label>
                        <input type="range" class="form-range voice-control-slider" id="voiceSpeed" 
                               min="0.5" max="2" step="0.1" value="1">
                        <div class="d-flex justify-content-between small">
                            <span>Slow</span>
                            <span>Normal</span>
                            <span>Fast</span>
                        </div>
                    </div>
                    <button class="btn btn-outline-primary w-100 btn-sm" onclick="testVoice()">
                        <i class="fas fa-play me-2"></i>Test Voice
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Mobile Controls -->
    <div class="mobile-controls">
        <div class="container-fluid">
            <div class="row g-1">
                <div class="col">
                    <a href="index.php" class="btn btn-outline-dark w-100 d-flex flex-column align-items-center py-2">
                        <i class="fas fa-home mb-1"></i>
                        <span class="small">Home</span>
                    </a>
                </div>
                <div class="col">
                    <button class="btn btn-outline-primary w-100 d-flex flex-column align-items-center py-2" onclick="addTicket()">
                        <i class="fas fa-plus mb-1"></i>
                        <span class="small">Add Ticket</span>
                    </button>
                </div>
                <div class="col">
                    <button class="btn btn-outline-success w-100 d-flex flex-column align-items-center py-2" onclick="speakCurrentNumber()">
                        <i class="fas fa-volume-up mb-1"></i>
                        <span class="small">Speak</span>
                    </button>
                </div>
                <div class="col">
                    <button class="btn btn-outline-warning w-100 d-flex flex-column align-items-center py-2" onclick="toggleFullscreen()">
                        <i class="fas fa-expand mb-1"></i>
                        <span class="small">Fullscreen</span>
                    </button>
                </div>
                <div class="col">
                    <button class="btn btn-outline-info w-100 d-flex flex-column align-items-center py-2" onclick="$('#autoVoice').click()">
                        <i class="fas fa-bell mb-1"></i>
                        <span class="small">Voice</span>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Winner Announcement Popup -->
    <div class="winner-announcement" id="winnerPopup">
        <h3 class="mb-2">🎉 WINNER! 🎉</h3>
        <h5 id="winnerName"></h5>
        <p id="winnerPattern" class="mb-2"></p>
        <h4 class="text-success mb-3" id="winnerPrize"></h4>
        <p class="small mb-2" id="winnerMessage">Prize auto-claimed and shown to host!</p>
        <button class="btn btn-dark w-100 py-2" onclick="closeWinnerPopup()">
            <i class="fas fa-times me-2"></i>Close
        </button>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Game variables
        const gameCode = '<?php echo $game_code; ?>';
        const gameId = <?php echo $game['id']; ?>;
        const gameName = '<?php echo addslashes($game['game_name']); ?>';
        const patternsEnabled = <?php echo json_encode($patterns_enabled); ?>;
        const patternPrizes = <?php echo json_encode($pattern_prizes); ?>;
        let tickets = {};
        let activeTicketCode = null;
        let calledNumbers = <?php echo json_encode($called_numbers); ?>;
        let lastAnnouncedNumber = null;
        let autoVoiceEnabled = true;
        let autoClaimEnabled = true;
        let voiceSpeed = 1;
        let callSpeed = <?php echo $auto_call_delay; ?>;
        let autoCallInterval = null;
        let autoClaimInProgress = false;
        let currentWinnerData = null;
        
        // Initialize
        $(document).ready(function() {
            // Set initial values
            autoVoiceEnabled = $('#autoVoice').is(':checked');
            autoClaimEnabled = $('#autoClaim').is(':checked');
            voiceSpeed = parseFloat($('#voiceSpeed').val());
            callSpeed = parseInt($('#callSpeed').val());
            
            // Show mobile controls on mobile
            if(window.innerWidth <= 768) {
                $('.mobile-controls').show();
            }
            
            // Start auto update and ping
            updateGameState();
            setInterval(updateGameState, 3000);
            setInterval(sendPing, 30000); // Ping every 30 seconds
            
            // Check for winners announcements
            checkWinnerAnnouncements();
            setInterval(checkWinnerAnnouncements, 5000);
            
            // Event listeners
            $('#autoVoice').change(function() {
                autoVoiceEnabled = $(this).is(':checked');
            });
            
            $('#autoClaim').change(function() {
                autoClaimEnabled = $(this).is(':checked');
            });
            
            $('#voiceSpeed').change(function() {
                voiceSpeed = parseFloat($(this).val());
            });
            
            $('#callSpeed').change(function() {
                callSpeed = parseInt($(this).val());
                updateAutoCallSpeed();
            });
            
            // Enter key for ticket code
            $('#ticketCode').keypress(function(e) {
                if(e.which == 13) addTicket();
            });
            
            // Load ticket from URL parameter
            const urlParams = new URLSearchParams(window.location.search);
            const ticketParam = urlParams.get('ticket');
            if(ticketParam) {
                $('#ticketCode').val(ticketParam);
                addTicket();
            }
            
            // Adjust UI on window resize
            $(window).resize(function() {
                if(window.innerWidth <= 768) {
                    $('.mobile-controls').show();
                } else {
                    $('.mobile-controls').hide();
                }
            });
        });
        
        // Keep page active with ping
        function sendPing() {
            $.ajax({
                url: 'api.php',
                method: 'POST',
                data: { action: 'ping', game_code: gameCode },
                success: function() {
                    $('#onlineStatus').html('🟢 Online');
                },
                error: function() {
                    $('#onlineStatus').html('🔴 Offline');
                }
            });
        }
        
        // Add ticket
        function addTicket() {
            const ticketCode = $('#ticketCode').val().trim();
            if(!ticketCode) {
                alert('Please enter ticket code');
                return;
            }
            
            if(tickets[ticketCode]) {
                alert('Ticket already added!');
                return;
            }
            
            $.ajax({
                url: 'api.php',
                method: 'POST',
                data: { 
                    action: 'get_ticket',
                    ticket_code: ticketCode,
                    game_code: gameCode
                },
                success: function(response) {
                    if(response.success) {
                        // Add to tickets object
                        tickets[ticketCode] = {
                            numbers: response.numbers,
                            cornerIndices: [],
                            corners: [],
                            completedPatterns: {},
                            playerName: response.player_name || 'Player'
                        };
                        
                        // Calculate corners for this ticket
                        calculateCorners(ticketCode);
                        
                        // Update tickets list
                        updateTicketsList();
                        
                        // Set as active if first ticket
                        if(activeTicketCode === null) {
                            setActiveTicket(ticketCode);
                        }
                        
                        // Clear input
                        $('#ticketCode').val('');
                        
                        // Display ticket
                        displayTicket(ticketCode);
                    } else {
                        alert(response.error);
                    }
                }
            });
        }
        
        // Calculate corners based on first and last numbers in first and last rows
        function calculateCorners(ticketCode) {
            const ticket = tickets[ticketCode];
            if(!ticket || !ticket.numbers || ticket.numbers.length !== 27) return;
            
            const cornerIndices = [];
            const corners = [];
            
            // Find first row corners (row 0)
            let firstRowStartCol = -1;
            let firstRowEndCol = -1;
            
            for(let col = 0; col < 9; col++) {
                const index = 0 * 9 + col;
                if(ticket.numbers[index] > 0) {
                    firstRowStartCol = col;
                    break;
                }
            }
            
            for(let col = 8; col >= 0; col--) {
                const index = 0 * 9 + col;
                if(ticket.numbers[index] > 0) {
                    firstRowEndCol = col;
                    break;
                }
            }
            
            // Find last row corners (row 2)
            let lastRowStartCol = -1;
            let lastRowEndCol = -1;
            
            for(let col = 0; col < 9; col++) {
                const index = 2 * 9 + col;
                if(ticket.numbers[index] > 0) {
                    lastRowStartCol = col;
                    break;
                }
            }
            
            for(let col = 8; col >= 0; col--) {
                const index = 2 * 9 + col;
                if(ticket.numbers[index] > 0) {
                    lastRowEndCol = col;
                    break;
                }
            }
            
            if(firstRowStartCol !== -1) {
                const index = 0 * 9 + firstRowStartCol;
                cornerIndices.push(index);
                corners.push(ticket.numbers[index]);
            }
            
            if(firstRowEndCol !== -1 && firstRowEndCol !== firstRowStartCol) {
                const index = 0 * 9 + firstRowEndCol;
                cornerIndices.push(index);
                corners.push(ticket.numbers[index]);
            }
            
            if(lastRowStartCol !== -1) {
                const index = 2 * 9 + lastRowStartCol;
                cornerIndices.push(index);
                corners.push(ticket.numbers[index]);
            }
            
            if(lastRowEndCol !== -1 && lastRowEndCol !== lastRowStartCol) {
                const index = 2 * 9 + lastRowEndCol;
                cornerIndices.push(index);
                corners.push(ticket.numbers[index]);
            }
            
            ticket.cornerIndices = cornerIndices;
            ticket.corners = corners;
        }
        
        // Update tickets list UI
        function updateTicketsList() {
            let html = '';
            Object.keys(tickets).forEach(ticketCode => {
                const isActive = ticketCode === activeTicketCode;
                html += `
                    <span class="ticket-badge ${isActive ? 'active' : ''}" onclick="setActiveTicket('${ticketCode}')">
                        ${ticketCode}
                        <span class="remove-btn" onclick="removeTicket('${ticketCode}', event)">
                            <i class="fas fa-times"></i>
                        </span>
                    </span>
                `;
            });
            $('#ticketsList').html(html);
        }
        
        // Set active ticket
        function setActiveTicket(ticketCode) {
            activeTicketCode = ticketCode;
            updateTicketsList();
            displayTicket(ticketCode);
            checkPatterns();
        }
        
        // Remove ticket
        function removeTicket(ticketCode, event) {
            event.stopPropagation();
            delete tickets[ticketCode];
            
            if(activeTicketCode === ticketCode) {
                activeTicketCode = Object.keys(tickets)[0] || null;
            }
            
            updateTicketsList();
            
            if(activeTicketCode) {
                displayTicket(activeTicketCode);
            } else {
                $('#ticketDisplay').html('<p class="text-muted text-center py-3 small">Add your ticket codes to display</p>');
            }
        }
        
        // Display ticket
        function displayTicket(ticketCode) {
            const ticket = tickets[ticketCode];
            if(!ticket || !ticket.numbers || ticket.numbers.length !== 27) {
                return;
            }
            
            let html = `<h6 class="mb-2">Ticket: <code>${ticketCode}</code></h6>`;
            html += '<div class="ticket-grid">';
            
            // Create 3x9 grid
            for(let row = 0; row < 3; row++) {
                for(let col = 0; col < 9; col++) {
                    const index = row * 9 + col;
                    const number = ticket.numbers[index];
                    const hasNumber = number > 0;
                    const isMarked = hasNumber && calledNumbers.includes(number);
                    const isCorner = ticket.cornerIndices.includes(index);
                    
                    html += `<div class="ticket-cell ${hasNumber ? 'has-number' : ''} ${isMarked ? 'marked' : ''} ${isCorner ? 'corner' : ''}" 
                             data-number="${number}" data-index="${index}">
                             ${hasNumber ? number : ''}</div>`;
                }
            }
            
            html += '</div>';
            $('#ticketDisplay').html(html);
            checkPatterns();
        }
        
        // Share winner on WhatsApp
        function shareWinnerOnWhatsApp(playerName, patternType, ticketCode, prizeAmount) {
            const gameLink = window.location.href;
            const patternNames = {
                'top_line': 'Top Line',
                'bottom_line': 'Bottom Line',
                'corners': 'Corners',
                'middle_line': 'Middle Line',
                'full_house': 'Full House'
            };
            
            const patternName = patternNames[patternType] || patternType;
            
            const message = `🎉 ${playerName} WON in Tambola! 🎉\n\n` +
                          `Game: ${gameName}\n` +
                          `Pattern: ${patternName}\n` +
                          `Ticket: ${ticketCode}\n` +
                          `Prize: ₹${prizeAmount}\n` +
                          `Game Code: ${gameCode}\n\n` +
                          `Join the fun: ${gameLink}`;
            
            const encodedMessage = encodeURIComponent(message);
            const whatsappUrl = `https://wa.me/?text=${encodedMessage}`;
            window.open(whatsappUrl, '_blank');
        }
        
        // Voice functions
        function speak(text) {
            if(!autoVoiceEnabled) return;
            
            if('speechSynthesis' in window) {
                speechSynthesis.cancel();
                const utterance = new SpeechSynthesisUtterance(text);
                utterance.rate = voiceSpeed;
                utterance.volume = 1;
                utterance.pitch = 1;
                
                const voices = speechSynthesis.getVoices();
                const femaleVoice = voices.find(v => v.lang.startsWith('en') && v.name.includes('Female'));
                if(femaleVoice) utterance.voice = femaleVoice;
                
                speechSynthesis.speak(utterance);
            }
        }
        
        function speakCurrentNumber() {
            const num = $('#currentNumber').text();
            if(num && num !== '--') {
                speak(`Number ${num}`);
            }
        }
        
        function testVoice() {
            speak("Welcome to Tambola!");
        }
        
        // Game state update
        function updateGameState() {
            $.ajax({
                url: 'api.php',
                method: 'GET',
                data: { action: 'get_game_state', code: gameCode },
                success: function(response) {
                    if(response.current_number && response.current_number !== '--') {
                        $('#currentNumber').text(response.current_number);
                        
                        if(autoVoiceEnabled && lastAnnouncedNumber !== response.current_number) {
                            speak(`Number ${response.current_number}`);
                            lastAnnouncedNumber = response.current_number;
                        }
                    }
                    
                    if(response.called_numbers) {
                        calledNumbers = response.called_numbers;
                        updateNumberBoard();
                        updateCalledNumbersList();
                        
                        Object.keys(tickets).forEach(ticketCode => {
                            updateTicketDisplay(ticketCode);
                        });
                        
                        checkPatterns();
                    }
                }
            });
        }
        
        // Update number board
        function updateNumberBoard() {
            for(let i = 1; i <= 90; i++) {
                const $cell = $('#num-' + i);
                if(calledNumbers.includes(i)) {
                    $cell.addClass('called');
                } else {
                    $cell.removeClass('called');
                }
            }
        }
        
        // Update called numbers list
        function updateCalledNumbersList() {
            const recent = calledNumbers.slice(-12);
            let html = '';
            recent.forEach(num => {
                html += `<span class="badge bg-success me-1 mb-1">${num}</span>`;
            });
            $('#calledNumbersList').html(html);
        }
        
        // Update ticket display
        function updateTicketDisplay(ticketCode) {
            const ticket = tickets[ticketCode];
            if(!ticket) return;
            
            $(`.ticket-cell[data-index]`).each(function() {
                const index = parseInt($(this).data('index'));
                const number = ticket.numbers[index];
                if(number > 0 && calledNumbers.includes(number)) {
                    $(this).addClass('marked');
                } else {
                    $(this).removeClass('marked');
                }
            });
        }
        
        // Check winning patterns for active ticket
        function checkPatterns() {
            if(!activeTicketCode || autoClaimInProgress) return;
            
            const ticket = tickets[activeTicketCode];
            if(!ticket || !ticket.numbers || ticket.numbers.length !== 27) return;
            
            const results = {};
            
            Object.keys(patternsEnabled).forEach(pattern => {
                if(patternsEnabled[pattern]) {
                    switch(pattern) {
                        case 'top_line':
                            results[pattern] = checkLine(0, ticket);
                            break;
                        case 'bottom_line':
                            results[pattern] = checkLine(2, ticket);
                            break;
                        case 'middle_line':
                            results[pattern] = checkLine(1, ticket);
                            break;
                        case 'corners':
                            results[pattern] = checkCorners(ticket);
                            break;
                        case 'full_house':
                            results[pattern] = checkFullHouse(ticket);
                            break;
                    }
                }
            });
            
            Object.keys(results).forEach(pattern => {
                const $badge = $('#pattern-' + pattern);
                const wasCompleted = ticket.completedPatterns[pattern] || false;
                const isCompleted = results[pattern];
                
                if(isCompleted && !wasCompleted) {
                    // Pattern just completed
                    autoClaimInProgress = true;
                    ticket.completedPatterns[pattern] = true;
                    $badge.addClass('completed');
                    
                    const prize = patternPrizes[pattern] || 0;
                    const patternNames = {
                        'top_line': 'Top Line',
                        'bottom_line': 'Bottom Line',
                        'corners': 'Corners',
                        'middle_line': 'Middle Line',
                        'full_house': 'Full House'
                    };
                    
                    // Auto claim if enabled
                    if(autoClaimEnabled && prize > 0) {
                        claimPrize(activeTicketCode, pattern, prize, patternNames[pattern]);
                    } else if(prize > 0) {
                        // Manual claim if auto claim is off
                        const msg = `🎉 Ticket ${activeTicketCode}: You completed ${patternNames[pattern]}! Prize: ₹${prize}`;
                        if(confirm(msg + '\n\nClaim prize and show to host?')) {
                            claimPrize(activeTicketCode, pattern, prize, patternNames[pattern]);
                        }
                    }
                    
                    setTimeout(() => { autoClaimInProgress = false; }, 1000);
                } else if(isCompleted) {
                    $badge.addClass('completed');
                } else {
                    $badge.removeClass('completed');
                }
            });
            
            const completed = Object.values(results).filter(Boolean).length;
            const total = Object.keys(patternsEnabled).filter(p => patternsEnabled[p]).length;
            $('#patternStatus').text(`Completed ${completed} of ${total} patterns`);
        }
        
        function checkLine(row, ticket) {
            for(let col = 0; col < 9; col++) {
                const index = row * 9 + col;
                const number = ticket.numbers[index];
                if(number > 0 && !calledNumbers.includes(number)) {
                    return false;
                }
            }
            return true;
        }
        
        function checkCorners(ticket) {
            return ticket.corners.every(number => calledNumbers.includes(number));
        }
        
        function checkFullHouse(ticket) {
            return ticket.numbers.every(num => num === 0 || calledNumbers.includes(num));
        }
        
        // Auto claim prize and show to host
        function claimPrize(ticketCode, pattern, prize, patternName) {
            const ticket = tickets[ticketCode];
            if(!ticket) return;
            
            $.ajax({
                url: 'api.php',
                method: 'POST',
                data: {
                    action: 'claim_prize',
                    game_code: gameCode,
                    ticket_code: ticketCode,
                    pattern: pattern,
                    prize: prize,
                    player_name: ticket.playerName
                },
                success: function(response) {
                    if(response.success) {
                        // Store winner data for WhatsApp sharing
                        currentWinnerData = {
                            player_name: ticket.playerName,
                            ticket_code: ticketCode,
                            pattern_type: pattern,
                            prize_amount: prize
                        };
                        
                        // Show winner announcement
                        showWinnerAnnouncement(currentWinnerData, true);
                        
                        // Update pattern badge
                        const $badge = $('#pattern-' + pattern);
                        $badge.addClass('won');
                        $badge.append('<span class="auto-claim-badge">✓</span>');
                        
                        // Show notification
                        if(!autoClaimEnabled) {
                            alert(`✅ Prize claimed successfully and shown to host!`);
                        }
                    } else {
                        alert('Error: ' + response.error);
                    }
                },
                error: function() {
                    alert('Error claiming prize. Please try again.');
                }
            });
        }
        
        // Check for winner announcements
        function checkWinnerAnnouncements() {
            $.ajax({
                url: 'api.php',
                method: 'GET',
                data: { action: 'get_first_winners', game_id: gameId },
                success: function(response) {
                    if(response.winners && response.winners.length > 0) {
                        updateWinnersList(response.winners);
                        
                        response.winners.forEach(winner => {
                            if(!window.seenWinners) window.seenWinners = [];
                            if(!window.seenWinners.includes(winner.id)) {
                                window.seenWinners.push(winner.id);
                                showWinnerAnnouncement(winner, false);
                            }
                        });
                    }
                }
            });
        }
        
        function updateWinnersList(winners) {
            let html = '';
            if(winners.length === 0) {
                html = '<p class="text-muted text-center py-3 small">No winners yet. Be the first!</p>';
            } else {
                winners.forEach(winner => {
                    const patternNames = {
                        'top_line': 'Top Line',
                        'bottom_line': 'Bottom Line',
                        'corners': 'Corners',
                        'middle_line': 'Middle Line',
                        'full_house': 'Full House'
                    };
                    
                    html += `
                    <div class="winner-card" data-winner-id="${winner.id}">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="mb-1">🎉 ${winner.player_name}</h6>
                                <p class="mb-0 small">Ticket: <code>${winner.ticket_code}</code></p>
                            </div>
                            <div class="text-end">
                                <span class="badge bg-dark">${patternNames[winner.pattern_type]}</span>
                                <h5 class="mb-0 text-success">₹${parseInt(winner.prize_amount)}</h5>
                            </div>
                        </div>`;
                    
                    // Add WhatsApp share button only for Full House winners
                    if(winner.pattern_type === 'full_house') {
                        html += `
                        <button class="whatsapp-share-btn" onclick="shareWinnerOnWhatsApp(
                            '${winner.player_name.replace(/'/g, "\\'")}',
                            '${winner.pattern_type}',
                            '${winner.ticket_code}',
                            ${winner.prize_amount}
                        )">
                            <i class="fab fa-whatsapp"></i> Share Win
                        </button>`;
                    }
                    
                    html += `</div>`;
                });
            }
            $('#winnersList').html(html);
        }
        
        function showWinnerAnnouncement(winner, isAutoClaimed) {
            const patternNames = {
                'top_line': 'Top Line',
                'bottom_line': 'Bottom Line',
                'corners': 'Corners',
                'middle_line': 'Middle Line',
                'full_house': 'Full House'
            };
            
            $('#winnerName').text(winner.player_name);
            $('#winnerPattern').text(`Won ${patternNames[winner.pattern_type]} on ticket ${winner.ticket_code}`);
            $('#winnerPrize').text(`₹${parseInt(winner.prize_amount)}`);
            
            if(isAutoClaimed) {
                $('#winnerMessage').text('Prize auto-claimed and shown to host!');
            } else {
                $('#winnerMessage').text('First winner for this pattern!');
            }
            
            $('#winnerPopup').fadeIn();
            
            // Announce winner with voice
            speak(`Congratulations to ${winner.player_name} for winning ${patternNames[winner.pattern_type]} with prize amount ${winner.prize_amount} rupees!`);
            
            // Auto close after 8 seconds
            setTimeout(closeWinnerPopup, 8000);
        }
        
        function closeWinnerPopup() {
            $('#winnerPopup').fadeOut();
            currentWinnerData = null;
        }
        
        // Auto-call system
        function updateAutoCallSpeed() {
            if(autoCallInterval) clearInterval(autoCallInterval);
            
            if(callSpeed > 0) {
                autoCallInterval = setInterval(function() {
                    if(calledNumbers.length < 90) {
                        $.ajax({
                            url: 'api.php',
                            method: 'POST',
                            data: {
                                action: 'auto_call_number',
                                game_code: gameCode
                            }
                        });
                    } else {
                        clearInterval(autoCallInterval);
                    }
                }, callSpeed * 1000);
            }
        }
        
        function toggleFullscreen() {
            if(!document.fullscreenElement) {
                const elem = document.documentElement;
                if(elem.requestFullscreen) {
                    elem.requestFullscreen();
                } else if(elem.webkitRequestFullscreen) {
                    elem.webkitRequestFullscreen();
                } else if(elem.msRequestFullscreen) {
                    elem.msRequestFullscreen();
                }
            } else {
                if(document.exitFullscreen) {
                    document.exitFullscreen();
                } else if(document.webkitExitFullscreen) {
                    document.webkitExitFullscreen();
                } else if(document.msExitFullscreen) {
                    document.msExitFullscreen();
                }
            }
        }
        
        // Handle orientation change
        window.addEventListener('orientationchange', function() {
            setTimeout(function() {
                location.reload();
            }, 100);
        });
    </script>
</body>
</html>