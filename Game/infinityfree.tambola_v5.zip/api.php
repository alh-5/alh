<?php
require_once 'config.php';

header('Content-Type: application/json');

// Get action
$action = $_GET['action'] ?? ($_POST['action'] ?? '');

switch($action) {
    case 'get_games':
        $games_result = $conn->query("SELECT * FROM games WHERE status IN ('waiting', 'started') ORDER BY created_at DESC");
        $games_html = '';
        if($games_result->num_rows > 0) {
            while($game = $games_result->fetch_assoc()) {
                $called = json_decode($game['called_numbers'] ?? '[]', true);
                $count = count($called);
                
                $games_html .= '<div class="col-md-6 mb-3">
                    <div class="game-card h-100">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <h5>' . htmlspecialchars($game['game_name']) . '</h5>
                                <p class="mb-2">Code: <strong>' . $game['game_code'] . '</strong></p>
                                <p class="mb-2">Numbers: <strong>' . $count . '/90</strong></p>
                            </div>
                            <span class="badge bg-' . 
                                ($game['status'] == 'waiting' ? 'warning' : 
                                 ($game['status'] == 'started' ? 'success' : 'danger')) . 
                                ' p-2">' . strtoupper($game['status']) . '</span>
                        </div>
                        <div class="mt-3">
                            <a href="game.php?code=' . $game['game_code'] . '" 
                               class="btn btn-custom w-100">
                                <i class="fas fa-play me-2"></i>Join Game
                            </a>
                        </div>
                    </div>
                </div>';
            }
        } else {
            $games_html = '<div class="col-12 text-center py-5">
                <i class="fas fa-gamepad fa-3x text-muted mb-3"></i>
                <h5>No active games</h5>
                <p class="text-muted">Check back later</p>
            </div>';
        }
        echo json_encode(['games' => $games_html]);
        break;
        
    case 'get_game_state':
        $code = $_GET['code'] ?? '';
        $result = $conn->query("SELECT current_number, called_numbers, status FROM games WHERE game_code = '$code'");
        if($result->num_rows > 0) {
            $game = $result->fetch_assoc();
            $numbers = json_decode($game['called_numbers'] ?? '[]', true) ?: [];
            echo json_encode([
                'current_number' => $game['current_number'],
                'called_numbers' => $numbers,
                'status' => $game['status']
            ]);
        } else {
            echo json_encode(['error' => 'Game not found']);
        }
        break;
        
    case 'get_ticket':
        $ticket_code = $_POST['ticket_code'] ?? '';
        $game_code = $_POST['game_code'] ?? '';
        
        // Get game ID
        $game_result = $conn->query("SELECT id FROM games WHERE game_code = '$game_code'");
        if($game_result->num_rows === 0) {
            echo json_encode(['success' => false, 'error' => 'Game not found']);
            break;
        }
        $game = $game_result->fetch_assoc();
        $game_id = $game['id'];
        
        // Get ticket
        $stmt = $conn->prepare("SELECT numbers FROM tickets WHERE ticket_code = ? AND game_id = ?");
        $stmt->bind_param("si", $ticket_code, $game_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if($result->num_rows > 0) {
            $ticket = $result->fetch_assoc();
            $numbers = json_decode($ticket['numbers'], true);
            echo json_encode([
                'success' => true,
                'numbers' => $numbers
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'error' => 'Ticket not found or invalid game'
            ]);
        }
        break;
        
    case 'purchase_ticket':
        $game_code = $_POST['game_code'] ?? '';
        $player_name = $_POST['player_name'] ?? '';
        $player_email = $_POST['player_email'] ?? '';
        
        // Validate inputs
        if(empty($game_code) || empty($player_name) || empty($player_email)) {
            echo json_encode(['error' => 'All fields are required']);
            break;
        }
        
        // Get game
        $game_result = $conn->query("SELECT id FROM games WHERE game_code = '$game_code' AND status = 'waiting'");
        if($game_result->num_rows === 0) {
            echo json_encode(['error' => 'Game not found or already started']);
            break;
        }
        $game = $game_result->fetch_assoc();
        $game_id = $game['id'];
        
        // Get available ticket
        $stmt = $conn->prepare("SELECT ticket_code FROM tickets WHERE game_id = ? AND purchase_status = 'available' LIMIT 1");
        $stmt->bind_param("i", $game_id);
        $stmt->execute();
        $ticket_result = $stmt->get_result();
        
        if($ticket_result->num_rows === 0) {
            echo json_encode(['error' => 'No tickets available for this game']);
            break;
        }
        
        $ticket = $ticket_result->fetch_assoc();
        $ticket_code = $ticket['ticket_code'];
        
        // Update ticket
        $stmt = $conn->prepare("UPDATE tickets SET player_name = ?, player_email = ?, purchase_status = 'sold', purchased_at = NOW() WHERE ticket_code = ?");
        $stmt->bind_param("sss", $player_name, $player_email, $ticket_code);
        
        if($stmt->execute()) {
            echo json_encode([
                'success' => true,
                'ticket_code' => $ticket_code,
                'message' => 'Ticket purchased successfully!'
            ]);
        } else {
            echo json_encode(['error' => 'Failed to purchase ticket']);
        }
        break;
        
    case 'call_number':
        $game_code = $_POST['game_code'] ?? $game_id = $_POST['game_id'] ?? 0;
        
        if($game_code) {
            $result = $conn->query("SELECT id FROM games WHERE game_code = '$game_code'");
            if($result->num_rows > 0) {
                $game = $result->fetch_assoc();
                $game_id = $game['id'];
            }
        }
        
        $result = $conn->query("SELECT called_numbers FROM games WHERE id = $game_id");
        if($result->num_rows > 0) {
            $game = $result->fetch_assoc();
            $called = json_decode($game['called_numbers'] ?? '[]', true);
            
            if(count($called) >= 90) {
                echo json_encode(['error' => 'All numbers called']);
                break;
            }
            
            // Generate unique number
            $all_numbers = range(1, 90);
            $available = array_diff($all_numbers, $called);
            
            if(count($available) > 0) {
                $new_number = $available[array_rand($available)];
                $called[] = $new_number;
                $called_json = json_encode($called);
                
                $conn->query("UPDATE games SET current_number = $new_number, called_numbers = '$called_json' WHERE id = $game_id");
                echo json_encode(['success' => true, 'number' => $new_number]);
            } else {
                echo json_encode(['error' => 'No numbers left']);
            }
        } else {
            echo json_encode(['error' => 'Game not found']);
        }
        break;
        
    case 'auto_call_number':
        $game_code = $_POST['game_code'] ?? '';
        
        $result = $conn->query("SELECT id, auto_call_delay FROM games WHERE game_code = '$game_code' AND status = 'started'");
        if($result->num_rows > 0) {
            $game = $result->fetch_assoc();
            $game_id = $game['id'];
            $delay = $game['auto_call_delay'];
            
            if($delay > 0) {
                // Call number (same logic as above)
                $called_result = $conn->query("SELECT called_numbers FROM games WHERE id = $game_id");
                $game_data = $called_result->fetch_assoc();
                $called = json_decode($game_data['called_numbers'] ?? '[]', true);
                
                if(count($called) < 90) {
                    $all_numbers = range(1, 90);
                    $available = array_diff($all_numbers, $called);
                    $new_number = $available[array_rand($available)];
                    $called[] = $new_number;
                    $called_json = json_encode($called);
                    
                    $conn->query("UPDATE games SET current_number = $new_number, called_numbers = '$called_json' WHERE id = $game_id");
                    echo json_encode(['success' => true, 'number' => $new_number]);
                }
            }
        }
        break;
        
    case 'get_recent_winners':
        $game_id = $_GET['game_id'] ?? 0;
        
        $query = "SELECT * FROM wins WHERE game_id = $game_id ORDER BY claimed_at DESC LIMIT 5";
        $result = $conn->query($query);
        $winners = [];
        
        while($row = $result->fetch_assoc()) {
            $winners[] = $row;
        }
        
        echo json_encode(['winners' => $winners]);
        break;
        
    case 'claim_prize':
        $game_code = $_POST['game_code'] ?? '';
        $ticket_code = $_POST['ticket_code'] ?? '';
        $pattern = $_POST['pattern'] ?? '';
        $prize = floatval($_POST['prize'] ?? 0);
        
        // Get game ID
        $game_result = $conn->query("SELECT id FROM games WHERE game_code = '$game_code'");
        if($game_result->num_rows === 0) {
            echo json_encode(['success' => false, 'error' => 'Game not found']);
            break;
        }
        $game = $game_result->fetch_assoc();
        $game_id = $game['id'];
        
        // Get ticket info
        $ticket_result = $conn->query("SELECT player_name FROM tickets WHERE ticket_code = '$ticket_code' AND game_id = $game_id");
        if($ticket_result->num_rows === 0) {
            echo json_encode(['success' => false, 'error' => 'Ticket not found']);
            break;
        }
        $ticket = $ticket_result->fetch_assoc();
        $player_name = $ticket['player_name'];
        
        // Check if already claimed
        $claimed_result = $conn->query("SELECT id FROM wins WHERE ticket_code = '$ticket_code' AND pattern_type = '$pattern'");
        if($claimed_result->num_rows > 0) {
            echo json_encode(['success' => false, 'error' => 'Prize already claimed']);
            break;
        }
        
        // Insert win
        $stmt = $conn->prepare("INSERT INTO wins (game_id, ticket_code, player_name, pattern_type, prize_amount) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("isssd", $game_id, $ticket_code, $player_name, $pattern, $prize);
        
        if($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Prize claimed successfully']);
        } else {
            echo json_encode(['success' => false, 'error' => 'Failed to claim prize']);
        }
        break;
        
    default:
        echo json_encode(['error' => 'Invalid action']);
        break;
}


 
?>