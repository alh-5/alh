<?php
// Database configuration
define('DB_HOST', 'sql213.infinityfree.com');
define('DB_USER', 'if0_40876592');
define('DB_PASS', 'DxpZFUeYhfKDqcd');
define('DB_NAME', 'if0_40876592_tambola');

// Website configuration
define('SITE_URL', 'https://dbtambola.ct.ws/');
define('SITE_NAME', 'DB Tambola');

// Create connection
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set charset
$conn->set_charset("utf8mb4");

// Start session
session_start();

// Simple admin verification
function verifyAdmin($username, $password) {
    return ($username === 'dbareh' && $password === '1908');
}
?>