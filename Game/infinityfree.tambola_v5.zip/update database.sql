-- Add a table to track auto calls if not exists
CREATE TABLE IF NOT EXISTS auto_calls (
    id INT AUTO_INCREMENT PRIMARY KEY,
    game_id INT,
    last_called_at DATETIME,
    FOREIGN KEY (game_id) REFERENCES games(id) ON DELETE CASCADE
);

-- Add ended_at column to games table if not exists
ALTER TABLE games ADD COLUMN IF NOT EXISTS ended_at DATETIME;

-- Add auto_call_delay column if not exists
ALTER TABLE games ADD COLUMN IF NOT EXISTS auto_call_delay INT DEFAULT 5;

-- Add is_claimed column to wins table if not exists
ALTER TABLE wins ADD COLUMN IF NOT EXISTS is_claimed BOOLEAN DEFAULT 1;