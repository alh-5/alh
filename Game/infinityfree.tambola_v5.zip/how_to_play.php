<?php require_once 'config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>How to Play - DB Tambola</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        .content-card {
            background: white;
            border-radius: 20px;
            padding: 40px;
            margin: 30px auto;
            max-width: 800px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.2);
        }
        .step {
            margin-bottom: 30px;
            padding: 20px;
            border-left: 5px solid #4b6cb7;
            background: #f8f9fa;
            border-radius: 0 10px 10px 0;
        }
        .step-number {
            display: inline-block;
            width: 40px;
            height: 40px;
            line-height: 40px;
            text-align: center;
            background: #4b6cb7;
            color: white;
            border-radius: 50%;
            margin-right: 15px;
            font-weight: bold;
        }
        @media (max-width: 768px) {
            .content-card {
                margin: 15px;
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="content-card">
        <h1 class="text-center mb-4">🎯 How to Play DB Tambola</h1>
        
        <div class="step">
            <h4><span class="step-number">1</span> Join a Game</h4>
            <p>Go to the lobby and join an active game using the game code provided by the host.</p>
        </div>
        
        <div class="step">
            <h4><span class="step-number">2</span> Purchase Ticket</h4>
            <p>Buy a ticket for ₹50. Each ticket has 15 random numbers in a 3x9 grid.</p>
        </div>
        
        <div class="step">
            <h4><span class="step-number">3</span> Listen for Numbers</h4>
            <p>The host will call numbers from 1 to 90. Mark the numbers on your ticket as they are called.</p>
        </div>
        
        <div class="step">
            <h4><span class="step-number">4</span> Complete Patterns</h4>
            <p>Complete any of these patterns to win:</p>
            <ul>
                <li><strong>Top Line:</strong> All numbers in the first row</li>
                <li><strong>Middle Line:</strong> All numbers in the middle row</li>
                <li><strong>Bottom Line:</strong> All numbers in the bottom row</li>
                <li><strong>Corners:</strong> Four corner numbers</li>
                <li><strong>Full House:</strong> All 15 numbers on your ticket</li>
            </ul>
        </div>
        
        <div class="step">
            <h4><span class="step-number">5</span> Claim Your Win</h4>
            <p>When you complete a pattern, click the "Claim Win" button and notify the host.</p>
        </div>
        
        <div class="text-center mt-5">
            <a href="index.php" class="btn btn-primary btn-lg">
                <i class="fas fa-play me-2"></i> Start Playing
            </a>
        </div>
    </div>
</body>
</html>