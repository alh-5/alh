-- Add phone column to tickets table if it doesn't exist
ALTER TABLE tickets ADD COLUMN IF NOT EXISTS phone VARCHAR(20);

-- Add ticket_price column to games table
ALTER TABLE games ADD COLUMN IF NOT EXISTS ticket_price DECIMAL(10,2) DEFAULT 20.00;