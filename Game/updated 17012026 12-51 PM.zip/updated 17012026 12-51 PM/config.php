<?php
// Database configuration
define('DB_HOST', 'sql213.infinityfree.com');
define('DB_USER', 'if0_40876592');
define('DB_PASS', 'DxpZFUeYhfKDqcd');
define('DB_NAME', 'if0_40876592_tambola');

// Website configuration
define('SITE_URL', 'https://dbtambola.ct.ws/');
define('SITE_NAME', 'DB Tambola');

// Admin credentials
define('ADMIN_USERNAME', 'dbareh');
define('ADMIN_PASSWORD', '190894'); // Change this to update password

// Session timeout (in seconds) - 15 hours
define('SESSION_TIMEOUT', 900);

// Create connection
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set charset
$conn->set_charset("utf8mb4");

// Start session
session_start();

// Simple admin verification with hash
function verifyAdmin($username, $password) {
    // Trim inputs
    $username = trim($username);
    $password = trim($password);
    
    // Verify credentials
    if ($username === ADMIN_USERNAME && $password === ADMIN_PASSWORD) {
        return true;
    }
    return false;
}

// Check session timeout
function checkSessionTimeout() {
    if (isset($_SESSION['admin_login_time'])) {
        $session_life = time() - $_SESSION['admin_login_time'];
        if ($session_life > SESSION_TIMEOUT) {
            session_destroy();
            header('Location: admin_login.php?msg=session_expired');
            exit;
        }
        // Update session time on activity
        $_SESSION['admin_login_time'] = time();
    }
}

// Check if password has changed
function checkPasswordChanged() {
    if (isset($_SESSION['admin_password_hash'])) {
        $current_hash = md5(ADMIN_PASSWORD);
        if ($_SESSION['admin_password_hash'] !== $current_hash) {
            session_destroy();
            header('Location: admin_login.php?msg=password_changed');
            exit;
        }
    }
}
?>