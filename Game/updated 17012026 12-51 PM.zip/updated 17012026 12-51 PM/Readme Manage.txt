For second adjustment

search
$auto_call_delay = $game['auto_call_delay'] ?? 8;

here 8 indicate 8 sec

<input type="range" class="form-range voice-control-slider" id="callSpeed" 
       min="1" max="60" value="<?php echo $auto_call_delay; ?>">