<?php
require_once 'config.php';

// Get active games with ticket count
$games_query = "SELECT g.*, 
               (SELECT COUNT(*) FROM tickets t WHERE t.game_id = g.id AND t.purchase_status = 'sold') as sold_tickets
               FROM games g 
               WHERE g.status IN ('waiting', 'started') 
               ORDER BY g.created_at DESC";
$games_result = $conn->query($games_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DB Tambola - Play Online Housie</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #4b6cb7;
            --secondary: #182848;
            --accent: #ff5722;
            --whatsapp: #25D366;
        }
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .hero-section {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            border-radius: 20px;
            padding: 40px 20px;
            color: white;
            margin-bottom: 30px;
            text-align: center;
        }
        .game-card {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.1);
            transition: all 0.3s;
            border: none;
        }
        .game-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 25px rgba(0,0,0,0.15);
        }
        .btn-custom {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            border: none;
            padding: 12px 25px;
            border-radius: 10px;
            font-weight: 600;
            transition: all 0.3s;
        }
        .btn-custom:hover {
            transform: scale(1.05);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        .btn-custom:disabled {
            background: linear-gradient(135deg, #cccccc, #999999);
            cursor: not-allowed;
            transform: none;
        }
        .btn-custom:disabled:hover {
            transform: none;
            box-shadow: none;
        }
        .btn-whatsapp {
            background: var(--whatsapp);
            color: white;
            border: none;
            padding: 12px 25px;
            border-radius: 10px;
            font-weight: 600;
            transition: all 0.3s;
        }
        .btn-whatsapp:hover {
            background: #128C7E;
            transform: scale(1.05);
            box-shadow: 0 5px 15px rgba(37, 211, 102, 0.3);
        }
        .btn-whatsapp:disabled {
            background: #cccccc;
            cursor: not-allowed;
            transform: none;
        }
        .btn-whatsapp:disabled:hover {
            transform: none;
            box-shadow: none;
        }
        .number-badge {
            display: inline-block;
            width: 40px;
            height: 40px;
            line-height: 40px;
            border-radius: 50%;
            background: linear-gradient(135deg, #4CAF50, #2E7D32);
            color: white;
            font-weight: bold;
            margin: 5px;
            text-align: center;
        }
        .modal-backdrop {
            background: rgba(0,0,0,0.5);
        }
        .modal-content {
            border-radius: 20px;
            border: none;
        }
        .game-code-display {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 8px 15px;
            border-radius: 8px;
            font-family: monospace;
            font-size: 1.1em;
            cursor: pointer;
            transition: all 0.3s;
        }
        .game-code-display:hover {
            transform: scale(1.05);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        .share-buttons {
            display: flex;
            gap: 10px;
            margin-top: 10px;
        }
        .share-buttons button {
            flex: 1;
        }
        
        /* NEW: Tambola Ticket Styles - Clean Inside Border Only */
        .tambola-ticket {
            width: 100%;
            max-width: 280px;
            margin: 0 auto;
            border: 3px solid #4b6cb7;
            border-radius: 10px;
            overflow: hidden;
            background: white;
            position: relative;
        }
        
        .ticket-header {
            background: linear-gradient(135deg, #4b6cb7, #182848);
            color: white;
            padding: 8px;
            text-align: center;
            font-weight: bold;
            font-size: 14px;
        }
        
        .ticket-numbers {
            display: grid;
            grid-template-columns: repeat(9, 1fr);
            gap: 1px;
            background: #4b6cb7;
            padding: 1px;
        }
        
        .ticket-row {
            display: contents;
        }
        
        .ticket-cell {
            background: white;
            aspect-ratio: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 12px;
            position: relative;
            border: none;
        }
        
        .ticket-cell.has-number {
            background: white;
            color: #333;
        }
        
        .ticket-cell.empty {
            background: #f8f9fa;
        }
        
        /* Ticket Selection Styles */
        .ticket-container {
            position: relative;
            border: 2px solid #ddd;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 15px;
            transition: all 0.3s;
            background: white;
        }
        .ticket-container:hover {
            border-color: var(--primary);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .ticket-container.selected {
            border-color: var(--primary);
            background: rgba(75, 108, 183, 0.05);
        }
        .ticket-container-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }
        .ticket-select-btn {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            border: 2px solid #ddd;
            background: white;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s;
        }
        .ticket-select-btn.selected {
            background: var(--primary);
            border-color: var(--primary);
            color: white;
        }
        .ticket-luck {
            font-weight: bold;
            color: #4CAF50;
            font-size: 1.1em;
        }
        
        /* Steps navigation */
        .steps {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }
        .step {
            display: flex;
            align-items: center;
            flex-direction: column;
            position: relative;
            flex: 1;
        }
        .step-number {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #ddd;
            color: #666;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            margin-bottom: 5px;
            z-index: 2;
        }
        .step.active .step-number {
            background: var(--primary);
            color: white;
        }
        .step.completed .step-number {
            background: #4CAF50;
            color: white;
        }
        .step-line {
            position: absolute;
            top: 20px;
            left: 50%;
            right: -50%;
            height: 2px;
            background: #ddd;
            z-index: 1;
        }
        .step:last-child .step-line {
            display: none;
        }
        
        .step-title {
            font-size: 0.9em;
            color: #666;
        }
        .step.active .step-title {
            color: var(--primary);
            font-weight: bold;
        }
        
        /* Preview modal specific */
        .ticket-preview-container {
            max-width: 300px;
            margin: 0 auto;
        }
        
        /* Game Started Styles */
        .game-started-tag {
            position: absolute;
            top: 10px;
            right: 10px;
            background: linear-gradient(135deg, #FF416C, #FF4B2B);
            color: white;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.8em;
            font-weight: bold;
            z-index: 1;
        }
        
        /* REMOVED: Hide the green STARTED badge */
        .game-status-badge {
            display: none;
        }
        
        @media (max-width: 768px) {
            .hero-section h1 {
                font-size: 1.8rem;
            }
            .game-card {
                margin: 10px 5px;
            }
            .share-buttons {
                flex-direction: column;
            }
            .tambola-ticket {
                max-width: 250px;
            }
            .ticket-cell {
                font-size: 11px;
            }
        }
    </style>
</head>
<body>    
      
       <div class="container py-4">
        <!-- Header -->
        <div class="hero-section">
            <h1 class="display-4 fw-bold mb-3">🎯 DB Tambola</h1>
            <p class="lead mb-4">Play Online Housie with Friends & Family in Real-time</p>
            
            <div class="row">
                <div class="col-md-3 mb-3">
                    <div class="bg-white text-dark p-3 rounded">
                        <i class="fas fa-gamepad fa-2x mb-2 text-primary"></i>
                        <h6>Total Games</h6>
                        <?php $total = $conn->query("SELECT COUNT(*) as c FROM games")->fetch_assoc()['c']; ?>
                        <h4 class="mb-0"><?php echo $total; ?></h4>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="bg-white text-dark p-3 rounded">
                        <i class="fas fa-play-circle fa-2x mb-2 text-success"></i>
                        <h6>Active Games</h6>
                        <?php $active = $conn->query("SELECT COUNT(*) as c FROM games WHERE status='started'")->fetch_assoc()['c']; ?>
                        <h4 class="mb-0"><?php echo $active; ?></h4>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="bg-white text-dark p-3 rounded">
                        <i class="fas fa-ticket-alt fa-2x mb-2 text-warning"></i>
                        <h6>Total Tickets</h6>
                        <?php $tickets = $conn->query("SELECT COUNT(*) as c FROM tickets")->fetch_assoc()['c']; ?>
                        <h4 class="mb-0"><?php echo $tickets; ?></h4>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="bg-white text-dark p-3 rounded">
                        <i class="fas fa-trophy fa-2x mb-2 text-danger"></i>
                        <h6>Total Winners</h6>
                        <?php $winners = $conn->query("SELECT COUNT(*) as c FROM wins")->fetch_assoc()['c']; ?>
                        <h4 class="mb-0"><?php echo $winners; ?></h4>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="row">
            <!-- Active Games -->
            <div class="col-lg-8 mb-4">
                <div class="game-card">
                    <h4 class="mb-4"><i class="fas fa-play-circle me-2"></i> Active Games</h4>
                    <div class="row" id="gamesList">
                        <?php if ($games_result->num_rows > 0): ?>
                            <?php while($game = $games_result->fetch_assoc()): 
                                $called = json_decode($game['called_numbers'] ?? '[]', true);
                                $numbers_count = count($called);
                                $sold_tickets = $game['sold_tickets'];
                                $game_url = "http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . "/game.php?code=" . $game['game_code'];
                                $is_started = $game['status'] == 'started';
                            ?>
                                <div class="col-md-6 mb-3" id="game-<?php echo $game['game_code']; ?>">
                                    <div class="game-card h-100 position-relative">
                                        <?php if($is_started): ?>
                                            <div class="game-started-tag">
                                                <i class="fas fa-play-circle me-1"></i> GAME STARTED
                                            </div>
                                        <?php else: ?>
                                            <!-- Only show status badge for non-started games -->
                                            <span class="badge bg-warning p-2" style="position: absolute; top: 10px; right: 10px;">
                                                WAITING
                                            </span>
                                        <?php endif; ?>
                                        
                                        <div class="d-flex justify-content-between align-items-start">
                                            <div>
                                                <h5><?php echo htmlspecialchars($game['game_name']); ?></h5>
                                                <p class="mb-1">Numbers: <strong><?php echo $numbers_count; ?>/90</strong></p>
                                                <p class="mb-2">Players: <strong><?php echo $sold_tickets; ?></strong></p>
                                            </div>
                                        </div>
                                        
                                        <!-- Game Code Display -->
                                        <div class="mb-3">
                                            <label class="form-label mb-1">Game Code:</label>
                                            <div class="game-code-display text-center" 
                                                 onclick="copyToClipboard('<?php echo $game['game_code']; ?>', this)">
                                                <strong><?php echo $game['game_code']; ?></strong>
                                                <span class="copy-text ms-2"><i class="fas fa-copy"></i> Copy</span>
                                            </div>
                                        </div>
                                        
                                        <!-- Share Buttons -->
                                        <div class="share-buttons">
                                            <?php if($is_started): ?>
                                                <button class="btn btn-custom" disabled>
                                                    <i class="fas fa-ban me-2"></i>Game Started
                                                </button>
                                            <?php else: ?>
                                                <button class="btn btn-custom" 
                                                        onclick="openTicketSelectionModal('<?php echo $game['game_code']; ?>', '<?php echo htmlspecialchars($game['game_name']); ?>')">
                                                    <i class="fas fa-ticket-alt me-2"></i>Choose Tickets
                                                </button>
                                            <?php endif; ?>
                                            
                                            <button class="btn btn-whatsapp" 
                                                    onclick="shareOnWhatsApp('<?php echo $game['game_name']; ?>', '<?php echo $game['game_code']; ?>')">
                                                <i class="fab fa-whatsapp me-2"></i>Invite
                                            </button>
                                        </div>
                                        
                                        <a href="game.php?code=<?php echo $game['game_code']; ?>" 
                                           class="btn btn-outline-primary w-100 mt-2">
                                            <i class="fas fa-play-circle me-2"></i><?php echo $is_started ? 'Watch Game' : 'Join Game'; ?>
                                        </a>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <div class="col-12 text-center py-5">
                                <i class="fas fa-gamepad fa-3x text-muted mb-3"></i>
                                <h5>No active games at the moment</h5>
                                <p class="text-muted">Check back later or create a new game</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Recent Numbers -->
                <div class="game-card">
                    <h4 class="mb-3"><i class="fas fa-history me-2"></i>Recent Numbers Called</h4>
                    <div id="recentNumbers">
                        <?php
                        $recent_query = "SELECT called_numbers FROM games WHERE status='started' ORDER BY started_at DESC LIMIT 1";
                        $recent_result = $conn->query($recent_query);
                        if ($recent_result->num_rows > 0) {
                            $game = $recent_result->fetch_assoc();
                            $numbers = json_decode($game['called_numbers'] ?? '[]', true);
                            $recent = array_slice($numbers, -10);
                            foreach(array_reverse($recent) as $num) {
                                echo '<span class="number-badge">' . $num . '</span>';
                            }
                            if(empty($recent)) {
                                echo '<p class="text-muted text-center mb-0">No numbers called yet</p>';
                            }
                        } else {
                            echo '<p class="text-muted text-center mb-0">No active games</p>';
                        }
                        ?>
                    </div>
                </div>
            </div>

            <!-- Sidebar -->
            <div class="col-lg-4">
                <!-- Your Tickets -->
                <div class="game-card mb-4">
                    <h4 class="mb-3"><i class="fas fa-ticket-alt me-2"></i>Your Tickets</h4>
                    <div class="mb-3">
                        <div class="input-group">
                            <input type="text" id="checkTicketCode" class="form-control" 
                                   placeholder="Enter ticket code">
                            <button class="btn btn-primary" onclick="checkTicket()">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </div>
                    <div id="yourTickets">
                        <p class="text-muted text-center">Enter ticket code to view details</p>
                    </div>
                </div>

                <!-- How to Play -->
                <div class="game-card mb-4">
                    <h4 class="mb-3"><i class="fas fa-question-circle me-2"></i>How to Play</h4>
                    <ol class="list-group list-group-numbered">
                        <li class="list-group-item border-0 bg-transparent">Choose your preferred tickets before game starts</li>
                        <li class="list-group-item border-0 bg-transparent">Enter your details to book tickets</li>
                        <li class="list-group-item border-0 bg-transparent">Save your ticket code(s)</li>
                        <li class="list-group-item border-0 bg-transparent">Join the game room</li>
                        <li class="list-group-item border-0 bg-transparent">Enjoy and good luck! 🍀</li>
                    </ol>
                </div>

                <!-- Important Notice -->
                <div class="game-card mb-4">
                    <h4 class="mb-3"><i class="fas fa-exclamation-circle me-2 text-warning"></i>Important Notice</h4>
                    <div class="alert alert-warning mb-0">
                        <p class="mb-2"><strong><i class="fas fa-clock me-1"></i> Ticket Booking:</strong></p>
                        <p class="mb-2 small">• Tickets can only be selected <strong>BEFORE</strong> the game starts</p>
                        <p class="mb-0 small">• Once a game starts, ticket selection is <strong>DISABLED</strong></p>
                        <p class="mb-0 small">• Join started games to watch and play with existing tickets</p>
                    </div>
                </div>

                <!-- Admin Access -->
                <div class="game-card">
                    <h4 class="mb-3"><i class="fas fa-user-shield me-2"></i>Admin Access</h4>
                    <a href="admin_login.php" class="btn btn-dark w-100 mb-3">
                        <i class="fas fa-sign-in-alt me-2"></i>Admin Login
                    </a>
                    <div class="text-center">
                        <small class="text-muted">Need help? Contact: support@dbtambola.com</small>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Ticket Selection Modal -->
    <div class="modal fade" id="ticketSelectionModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Choose Your Tickets</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <!-- Steps Navigation -->
                    <div class="steps">
                        <div class="step active" id="step1">
                            <div class="step-number">1</div>
                            <div class="step-title">Select Tickets</div>
                            <div class="step-line"></div>
                        </div>
                        <div class="step" id="step2">
                            <div class="step-number">2</div>
                            <div class="step-title">Enter Details</div>
                            <div class="step-line"></div>
                        </div>
                        <div class="step" id="step3">
                            <div class="step-number">3</div>
                            <div class="step-title">Booked</div>
                        </div>
                    </div>
                    
                    <!-- Step 1: Ticket Selection -->
                    <div id="ticketSelectionStep">
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle me-2"></i>
                            <strong id="selectionGameName"></strong><br>
                            Game Code: <strong id="selectionGameCode"></strong>
                            <div class="mt-2">
                                <small>Select up to <span id="maxTickets">10</span> tickets. Click on tickets to preview them.</small>
                                <br><small class="text-success">🎯 Good luck with your tickets!</small>
                            </div>
                        </div>
                        
                        <!-- Selected Tickets Summary -->
                        <div class="alert alert-success" id="selectedSummary" style="display: none;">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <i class="fas fa-check-circle me-2"></i>
                                    <strong><span id="selectedCount">0</span> ticket(s) selected</strong>
                                    <div class="small" id="selectedCodes"></div>
                                </div>
                                <button class="btn btn-sm btn-success" onclick="proceedToDetails()">
                                    Proceed <i class="fas fa-arrow-right ms-1"></i>
                                </button>
                            </div>
                        </div>
                        
                        <!-- Tickets Container -->
                        <div class="row" id="ticketsContainer">
                            <!-- Tickets will be loaded here dynamically -->
                        </div>
                        
                        <!-- Pagination -->
                        <div class="d-flex justify-content-center mt-3" id="ticketsPagination">
                            <!-- Pagination will be loaded here -->
                        </div>
                    </div>
                    
                    <!-- Step 2: Enter Details -->
                    <div id="detailsStep" style="display: none;">
                        <div class="alert alert-success">
                            <i class="fas fa-ticket-alt me-2"></i>
                            You have selected <strong><span id="finalTicketCount">0</span> ticket(s)</strong>
                        </div>
                        
                        <form id="purchaseForm">
                            <input type="hidden" id="purchaseGameCode" name="game_code">
                            <input type="hidden" id="selectedTicketCodes" name="selected_ticket_codes">
                            
                            <div class="mb-3">
                                <label class="form-label">Full Name *</label>
                                <input type="text" id="playerName" class="form-control" required 
                                       placeholder="Enter your full name">
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Email Address *</label>
                                <input type="email" id="playerEmail" class="form-control" required 
                                       placeholder="Enter your email">
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Phone Number *</label>
                                <input type="tel" id="playerPhone" class="form-control" required 
                                       placeholder="Enter your phone number (10 digits)">
                            </div>
                            
                            <!-- Selected Tickets Preview -->
                            <div class="mb-3">
                                <label class="form-label">Selected Tickets:</label>
                                <div id="selectedTicketsPreview" class="border rounded p-3" style="max-height: 200px; overflow-y: auto;">
                                    <!-- Selected tickets will be shown here -->
                                </div>
                            </div>
                            
                            <!-- Booking Summary -->
                            <div class="alert alert-success">
                                <h6>🎉 You're ready to play!</h6>
                                <p class="mb-0">You have selected <strong><span id="summaryCount">0</span> ticket(s)</strong>. 
                                Click "Book Now" to secure your tickets.</p>
                            </div>
                        </form>
                    </div>
                    
                    <!-- Step 3: Booking -->
                    <div id="bookingStep" style="display: none;">
                        <div class="text-center py-4">
                            <div class="mb-3">
                                <i class="fas fa-ticket-alt fa-3x text-primary mb-3"></i>
                                <h4>Booking Tickets</h4>
                                <p class="text-muted">Securing your tickets...</p>
                            </div>
                            <div class="spinner-border text-primary" role="status">
                                <span class="visually-hidden">Loading...</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="previousStep()" id="prevBtn" style="display: none;">
                        <i class="fas fa-arrow-left me-2"></i>Back
                    </button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" id="cancelBtn">Cancel</button>
                    <button type="button" class="btn btn-success" onclick="nextStep()" id="nextBtn">
                        <i class="fas fa-ticket-alt me-2"></i>Select Tickets
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Ticket Preview Modal -->
    <div class="modal fade" id="ticketPreviewModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Ticket Preview</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="ticket-preview-container">
                        <div id="ticketPreviewContent">
                            <!-- Ticket preview will be shown here -->
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-sm btn-primary" id="selectTicketBtn" onclick="selectTicketFromPreview()">
                        <i class="fas fa-check me-1"></i>Select Ticket
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Game Started Alert Modal -->
    <div class="modal fade" id="gameStartedAlert" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header bg-warning">
                    <h5 class="modal-title text-white"><i class="fas fa-exclamation-triangle me-2"></i>Game Already Started</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="text-center">
                        <i class="fas fa-play-circle fa-4x text-warning mb-3"></i>
                        <h4>This Game Has Started!</h4>
                        <p class="text-muted">Ticket selection is only available before the game begins.</p>
                        <div class="alert alert-info">
                            <p class="mb-1"><strong>What you can do:</strong></p>
                            <p class="mb-0 small">1. Join the game to watch and play with existing tickets</p>
                            <p class="mb-0 small">2. Look for other games that haven't started yet</p>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" id="joinStartedGameBtn">
                        <i class="fas fa-play-circle me-2"></i>Join Game
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Global variables
        let selectedTickets = [];
        let currentPage = 1;
        let totalPages = 1;
        let ticketsPerPage = 12;
        let currentGameCode = '';
        let previewTicketCode = '';
        let startedGames = {}; // Track started games
        
        // Track which games have started
        function updateStartedGames() {
            $('.game-card').each(function() {
                const gameCode = $(this).closest('.col-md-6').attr('id').replace('game-', '');
                const isStarted = $(this).find('.game-started-tag').length > 0;
                startedGames[gameCode] = isStarted;
            });
        }
        
        // Initialize started games tracking
        $(document).ready(function() {
            updateStartedGames();
        });
        
        // Open ticket selection modal
        function openTicketSelectionModal(gameCode, gameName) {
            // Check if game has started
            if (startedGames[gameCode]) {
                showGameStartedAlert(gameCode, gameName);
                return;
            }
            
            selectedTickets = [];
            currentPage = 1;
            currentGameCode = gameCode;
            
            $('#selectionGameCode').text(gameCode);
            $('#selectionGameName').text(gameName);
            $('#purchaseGameCode').val(gameCode);
            
            // Reset steps
            resetSteps();
            showStep(1);
            
            // Load available tickets
            loadAvailableTickets();
            
            $('#ticketSelectionModal').modal('show');
        }
        
        // Load available tickets
        function loadAvailableTickets() {
            $.ajax({
                url: 'api.php',
                method: 'POST',
                data: {
                    action: 'get_available_tickets',
                    game_code: currentGameCode,
                    page: currentPage,
                    per_page: ticketsPerPage
                },
                success: function(response) {
                    if(response.success) {
                        displayTickets(response.tickets || []);
                        updatePagination(response.total_pages || 1);
                    } else {
                        // Check if game has started
                        if(response.error && response.error.includes('started')) {
                            showGameStartedAlert(currentGameCode, $('#selectionGameName').text());
                            $('#ticketSelectionModal').modal('hide');
                        } else {
                            showError('Error loading tickets: ' + (response.error || 'Unknown error'));
                        }
                    }
                },
                error: function(xhr, status, error) {
                    showError('Network error. Please try again.');
                }
            });
        }
        
        // Show game started alert
        function showGameStartedAlert(gameCode, gameName) {
            $('#joinStartedGameBtn').off('click').on('click', function() {
                joinGame(gameCode);
            });
            $('#gameStartedAlert').modal('show');
        }
        
        // Display tickets in clean tambola style
        function displayTickets(tickets) {
            const container = $('#ticketsContainer');
            container.empty();
            
            if(!tickets || tickets.length === 0) {
                container.html(`
                    <div class="col-12 text-center py-5">
                        <i class="fas fa-ticket-alt fa-3x text-muted mb-3"></i>
                        <h5>No tickets available</h5>
                        <p class="text-muted">All tickets for this game have been sold.</p>
                    </div>
                `);
                return;
            }
            
            tickets.forEach(ticket => {
                const isSelected = selectedTickets.includes(ticket.ticket_code);
                let numbers = [];
                
                try {
                    numbers = JSON.parse(ticket.numbers || '[]');
                } catch(e) {
                    numbers = [];
                }
                
                // Create tambola ticket HTML
                let ticketHtml = `
                    <div class="col-md-4 mb-3">
                        <div class="ticket-container ${isSelected ? 'selected' : ''}" 
                             onclick="previewTicket('${ticket.ticket_code}')">
                            <div class="ticket-container-header">
                                <div>
                                    <strong class="ticket-code">${ticket.ticket_code}</strong>
                                    <div class="small text-muted">Click to preview</div>
                                </div>
                                <div class="ticket-select-btn ${isSelected ? 'selected' : ''}" 
                                     onclick="event.stopPropagation(); toggleTicketSelection('${ticket.ticket_code}', event)">
                                    <i class="fas ${isSelected ? 'fa-check' : 'fa-plus'}"></i>
                                </div>
                            </div>
                            <div class="tambola-ticket">
                                <div class="ticket-header">TICKET</div>
                                <div class="ticket-numbers">
                `;
                
                // Generate 3 rows of 9 cells each
                for(let row = 0; row < 3; row++) {
                    ticketHtml += `<div class="ticket-row">`;
                    for(let col = 0; col < 9; col++) {
                        const cellIndex = row * 9 + col;
                        const number = numbers[cellIndex] || '';
                        const hasNumber = number !== '';
                        
                        ticketHtml += `
                            <div class="ticket-cell ${hasNumber ? 'has-number' : 'empty'}">
                                ${hasNumber ? number : ''}
                            </div>
                        `;
                    }
                    ticketHtml += `</div>`;
                }
                
                ticketHtml += `
                                </div>
                            </div>
                            <div class="mt-2 text-center">
                                <span class="ticket-luck">🍀 Good luck!</span>
                            </div>
                        </div>
                    </div>
                `;
                
                container.append(ticketHtml);
            });
            
            updateSelectedSummary();
        }
        
        // Update pagination
        function updatePagination(total) {
            totalPages = total;
            const pagination = $('#ticketsPagination');
            pagination.empty();
            
            if(totalPages <= 1) return;
            
            let paginationHtml = `<nav><ul class="pagination justify-content-center">`;
            
            // Previous button
            paginationHtml += `
                <li class="page-item ${currentPage === 1 ? 'disabled' : ''}">
                    <a class="page-link" href="#" onclick="changePage(${currentPage - 1}); return false;">
                        <i class="fas fa-chevron-left"></i>
                    </a>
                </li>
            `;
            
            // Page numbers
            for(let i = 1; i <= totalPages; i++) {
                if(i === 1 || i === totalPages || (i >= currentPage - 1 && i <= currentPage + 1)) {
                    paginationHtml += `
                        <li class="page-item ${currentPage === i ? 'active' : ''}">
                            <a class="page-link" href="#" onclick="changePage(${i}); return false;">${i}</a>
                        </li>
                    `;
                } else if(i === currentPage - 2 || i === currentPage + 2) {
                    paginationHtml += `<li class="page-item disabled"><span class="page-link">...</span></li>`;
                }
            }
            
            // Next button
            paginationHtml += `
                <li class="page-item ${currentPage === totalPages ? 'disabled' : ''}">
                    <a class="page-link" href="#" onclick="changePage(${currentPage + 1}); return false;">
                        <i class="fas fa-chevron-right"></i>
                    </a>
                </li>
            `;
            
            paginationHtml += `</ul></nav>`;
            pagination.html(paginationHtml);
        }
        
        // Change page
        function changePage(page) {
            if(page < 1 || page > totalPages) return;
            currentPage = page;
            loadAvailableTickets();
        }
        
        // Preview ticket
        function previewTicket(ticketCode) {
            previewTicketCode = ticketCode;
            
            $.ajax({
                url: 'api.php',
                method: 'POST',
                data: {
                    action: 'get_ticket_details',
                    ticket_code: ticketCode
                },
                success: function(response) {
                    if(response.success) {
                        showTicketPreview(response.ticket);
                    } else {
                        showError('Error loading ticket details');
                    }
                },
                error: function() {
                    showError('Network error. Please try again.');
                }
            });
        }
        
        // Show ticket preview in clean tambola style
        function showTicketPreview(ticket) {
            let numbers = ticket.numbers || [];
            if (typeof numbers === 'string') {
                try {
                    numbers = JSON.parse(numbers);
                } catch(e) {
                    numbers = [];
                }
            }
            
            const isSelected = selectedTickets.includes(ticket.ticket_code);
            
            let previewHtml = `
                <div class="text-center mb-3">
                    <h5>${ticket.ticket_code}</h5>
                    <div class="small text-muted">Game: ${ticket.game_name || 'Unknown'}</div>
                </div>
                <div class="tambola-ticket">
                    <div class="ticket-header">TICKET</div>
                    <div class="ticket-numbers">
            `;
            
            // Generate 3 rows of 9 cells each
            for(let row = 0; row < 3; row++) {
                previewHtml += `<div class="ticket-row">`;
                for(let col = 0; col < 9; col++) {
                    const cellIndex = row * 9 + col;
                    const number = numbers[cellIndex] || '';
                    const hasNumber = number !== '';
                    
                    previewHtml += `
                        <div class="ticket-cell ${hasNumber ? 'has-number' : 'empty'}">
                            ${hasNumber ? number : ''}
                        </div>
                    `;
                }
                previewHtml += `</div>`;
            }
            
            previewHtml += `
                    </div>
                </div>
                <div class="mt-3 text-center">
                    <div class="text-success"><i class="fas fa-smile"></i> Good luck playing!</div>
                    <div class="small text-muted mt-1">Status: ${ticket.purchase_status === 'available' ? 'Available' : 'Sold'}</div>
                </div>
            `;
            
            $('#ticketPreviewContent').html(previewHtml);
            
            // Update select button
            const selectBtn = $('#selectTicketBtn');
            if(ticket.purchase_status === 'sold') {
                selectBtn.prop('disabled', true).html('<i class="fas fa-times me-1"></i>Already Sold');
            } else if(isSelected) {
                selectBtn.removeClass('btn-primary').addClass('btn-danger')
                    .html('<i class="fas fa-trash me-1"></i>Remove');
            } else {
                selectBtn.removeClass('btn-danger').addClass('btn-primary')
                    .html('<i class="fas fa-check me-1"></i>Select Ticket');
            }
            
            $('#ticketPreviewModal').modal('show');
        }
        
        // Select ticket from preview
        function selectTicketFromPreview() {
            if(previewTicketCode) {
                toggleTicketSelection(previewTicketCode);
                $('#ticketPreviewModal').modal('hide');
            }
        }
        
        // Toggle ticket selection
        function toggleTicketSelection(ticketCode, event) {
            if(event) event.stopPropagation();
            
            const index = selectedTickets.indexOf(ticketCode);
            if(index === -1) {
                // Check max tickets
                if(selectedTickets.length >= 10) {
                    showError('You can select maximum 10 tickets');
                    return;
                }
                selectedTickets.push(ticketCode);
            } else {
                selectedTickets.splice(index, 1);
            }
            
            // Update UI
            loadAvailableTickets();
            updateSelectedSummary();
        }
        
        // Update selected tickets summary
        function updateSelectedSummary() {
            const count = selectedTickets.length;
            const summary = $('#selectedSummary');
            const selectedCount = $('#selectedCount');
            const selectedCodes = $('#selectedCodes');
            
            selectedCount.text(count);
            
            if(count > 0) {
                summary.show();
                // Show only first 3 codes if many selected
                const displayCodes = selectedTickets.length > 3 
                    ? selectedTickets.slice(0, 3).join(', ') + `... (+${selectedTickets.length - 3} more)`
                    : selectedTickets.join(', ');
                selectedCodes.text('Selected: ' + displayCodes);
                
                // Update next button text
                $('#nextBtn').html(`<i class="fas fa-arrow-right me-2"></i>Proceed (${count})`);
            } else {
                summary.hide();
                $('#nextBtn').html('<i class="fas fa-ticket-alt me-2"></i>Select Tickets');
            }
        }
        
        // Reset steps
        function resetSteps() {
            $('.step').removeClass('active completed');
            $('#step1').addClass('active');
            showStep(1);
        }
        
        // Show specific step
        function showStep(stepNumber) {
            console.log('Showing step:', stepNumber);
            
            // Hide all steps
            $('#ticketSelectionStep, #detailsStep, #bookingStep').hide();
            $('#prevBtn, #nextBtn').show();
            
            // Update steps UI
            $('.step').removeClass('active');
            $(`#step${stepNumber}`).addClass('active');
            
            // Mark previous steps as completed
            for(let i = 1; i < stepNumber; i++) {
                $(`#step${i}`).addClass('completed');
            }
            
            // Show current step
            if(stepNumber === 1) {
                $('#ticketSelectionStep').show();
                $('#prevBtn').hide();
                $('#nextBtn').html('<i class="fas fa-ticket-alt me-2"></i>Select Tickets');
                $('#cancelBtn').show();
            } else if(stepNumber === 2) {
                $('#detailsStep').show();
                prepareDetailsStep();
                $('#prevBtn').show();
                $('#nextBtn').html('<i class="fas fa-check me-2"></i>Book Now');
                $('#cancelBtn').show();
            } else if(stepNumber === 3) {
                $('#bookingStep').show();
                $('#prevBtn').hide();
                $('#nextBtn').hide();
                $('#cancelBtn').hide();
                processBooking();
            }
        }
        
        // Prepare details step
        function prepareDetailsStep() {
            $('#finalTicketCount').text(selectedTickets.length);
            $('#summaryCount').text(selectedTickets.length);
            
            // Update selected tickets preview
            const preview = $('#selectedTicketsPreview');
            preview.empty();
            
            selectedTickets.forEach((code, index) => {
                preview.append(`
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <div>
                            <strong>Ticket ${index + 1}:</strong> ${code}
                        </div>
                        <button type="button" class="btn btn-sm btn-outline-danger" onclick="removeTicket('${code}', event)">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                `);
            });
            
            // Set selected ticket codes in hidden field
            $('#selectedTicketCodes').val(selectedTickets.join(','));
        }
        
        // Remove ticket from selection
        function removeTicket(ticketCode, event) {
            if(event) event.stopPropagation();
            event.preventDefault();
            
            const index = selectedTickets.indexOf(ticketCode);
            if(index !== -1) {
                selectedTickets.splice(index, 1);
                prepareDetailsStep();
                loadAvailableTickets();
                updateSelectedSummary();
            }
        }
        
        // Navigate to next step
        function nextStep() {
            const currentStep = $('.step.active').attr('id').replace('step', '');
            console.log('Next step from:', currentStep);
            
            if(currentStep === '1') {
                // Check if tickets are selected
                if(selectedTickets.length === 0) {
                    showError('Please select at least one ticket');
                    return;
                }
                showStep(2);
            } else if(currentStep === '2') {
                // Validate form
                if(!validateBookingForm()) {
                    return;
                }
                showStep(3);
            }
        }
        
        // Navigate to previous step
        function previousStep() {
            const currentStep = $('.step.active').attr('id').replace('step', '');
            if(currentStep > 1) {
                showStep(parseInt(currentStep) - 1);
            }
        }
        
        // Validate booking form - PHONE IS REQUIRED (10 digits)
        function validateBookingForm() {
            const name = $('#playerName').val().trim();
            const email = $('#playerEmail').val().trim();
            const phone = $('#playerPhone').val().trim();
            
            // All fields are required as per your API
            if(!name) {
                showError('Please enter your full name');
                $('#playerName').focus();
                return false;
            }
            
            if(!email) {
                showError('Please enter your email address');
                $('#playerEmail').focus();
                return false;
            }
            
            if(!validateEmail(email)) {
                showError('Please enter a valid email address');
                $('#playerEmail').focus();
                return false;
            }
            
            if(!phone) {
                showError('Please enter your phone number');
                $('#playerPhone').focus();
                return false;
            }
            
            if(!validatePhone(phone)) {
                showError('Please enter a valid 10-digit phone number');
                $('#playerPhone').focus();
                return false;
            }
            
            return true;
        }
        
        // Process booking
        function processBooking() {
            const name = $('#playerName').val().trim();
            const email = $('#playerEmail').val().trim();
            const phone = $('#playerPhone').val().trim();
            const ticketCodes = selectedTickets.join(',');
            
            console.log('Processing booking for:', { name, email, phone, ticketCodes });
            
            // Show loading state
            $('#bookingStep').html(`
                <div class="text-center py-4">
                    <div class="mb-3">
                        <i class="fas fa-ticket-alt fa-3x text-primary mb-3"></i>
                        <h4>Booking Your Tickets</h4>
                        <p class="text-muted">Please wait while we secure your tickets...</p>
                    </div>
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                </div>
            `);
            
            // Make API call using YOUR API structure
            $.ajax({
                url: 'api.php',
                method: 'POST',
                data: {
                    action: 'purchase_tickets',
                    game_code: currentGameCode,
                    ticket_codes: ticketCodes,
                    player_name: name,
                    player_email: email,
                    phone: phone
                },
                success: function(response) {
                    console.log('Booking response:', response);
                    if(response.success) {
                        // Show success
                        showBookingSuccess(response.tickets || [], response.receipt || {});
                    } else {
                        showError('Booking failed: ' + (response.error || 'Unknown error'));
                        showStep(2); // Go back to details step
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Booking AJAX error:', error);
                    showError('Network error. Please try again.');
                    showStep(2);
                }
            });
        }
        
        // Show booking success
        function showBookingSuccess(tickets, receipt) {
            const modal = $('#ticketSelectionModal');
            modal.find('.modal-footer').hide();
            
            const bookingStep = $('#bookingStep');
            let ticketCodesHtml = '';
            
            if(tickets && tickets.length > 0) {
                tickets.forEach(ticket => {
                    ticketCodesHtml += `
                        <div class="d-inline-block m-2">
                            <div class="game-code-display" onclick="copyToClipboard('${ticket.code}', this)">
                                <strong>${ticket.code}</strong>
                                <span class="copy-text ms-2"><i class="fas fa-copy"></i> Copy</span>
                            </div>
                        </div>
                    `;
                });
            } else if(selectedTickets.length > 0) {
                // Fallback to selected tickets if tickets array is empty
                selectedTickets.forEach(ticketCode => {
                    ticketCodesHtml += `
                        <div class="d-inline-block m-2">
                            <div class="game-code-display" onclick="copyToClipboard('${ticketCode}', this)">
                                <strong>${ticketCode}</strong>
                                <span class="copy-text ms-2"><i class="fas fa-copy"></i> Copy</span>
                            </div>
                        </div>
                    `;
                });
            }
            
            bookingStep.html(`
                <div class="text-center py-5">
                    <div class="mb-4">
                        <div class="display-1 text-success">
                            <i class="fas fa-check-circle"></i>
                        </div>
                        <h3 class="text-success">Tickets Booked Successfully!</h3>
                        <p class="text-muted">Your tickets have been reserved. Good luck playing! 🍀</p>
                    </div>
                    
                    <div class="alert alert-success mb-4">
                        <h6>Your Ticket Codes:</h6>
                        <div class="text-center">
                            ${ticketCodesHtml || '<p>No ticket codes received</p>'}
                        </div>
                        <div class="mt-3">
                            <p class="text-primary mb-0">
                                <i class="fas fa-star"></i>
                                If ticket not Paid before 10 mins then ticket code will get terminate instantly!
                            </p>
                        </div>
                    </div>
                    
                    <div class="alert alert-info mb-4">
                        <h6>Booking Details:</h6>
                        <p><strong>Booking ID:</strong> ${receipt.id || 'RCT' + Date.now().toString().slice(-8)}</p>
                        <p><strong>Player:</strong> ${$('#playerName').val()}</p>
                        <p><strong>Email:</strong> ${$('#playerEmail').val()}</p>
                        <p><strong>Phone:</strong> ${$('#playerPhone').val()}</p>
                        <p><strong>Total Tickets:</strong> ${selectedTickets.length}</p>
                        <p><strong>Date:</strong> ${new Date().toLocaleDateString()}</p>
                    </div>
                    
                    <div class="d-grid gap-2">
                        <button class="btn btn-primary" onclick="joinGame('${currentGameCode}')">
                            <i class="fas fa-play me-2"></i>Join Game Now
                        </button>
                        <button class="btn btn-outline-secondary" onclick="closeModalAndReset()">
                            Close
                        </button>
                    </div>
                </div>
            `);
        }
        
        // Proceed to details step
        function proceedToDetails() {
            // Check if tickets are selected before proceeding
            if(selectedTickets.length === 0) {
                showError('Please select at least one ticket');
                return;
            }
            showStep(2);
        }
        
        // Close modal and reset
        function closeModalAndReset() {
            $('#ticketSelectionModal').modal('hide');
            selectedTickets = [];
            currentPage = 1;
            
            // Reset form
            $('#playerName').val('');
            $('#playerEmail').val('');
            $('#playerPhone').val('');
        }
        
        // Show all tickets
        function showAllTickets() {
            ticketsPerPage = 48;
            loadAvailableTickets();
        }
        
        // Validate email
        function validateEmail(email) {
            const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return re.test(email);
        }
        
        // Validate phone - 10 DIGITS REQUIRED
        function validatePhone(phone) {
            const re = /^[0-9]{10}$/;
            return re.test(phone);
        }
        
        // Show error message
        function showError(message) {
            // Remove existing toasts
            $('.toast').remove();
            
            // Create and show error toast
            const toast = $(`
                <div class="position-fixed top-0 end-0 p-3" style="z-index: 9999">
                    <div class="toast show" role="alert">
                        <div class="toast-header bg-danger text-white">
                            <strong class="me-auto"><i class="fas fa-exclamation-circle me-2"></i>Error</strong>
                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast"></button>
                        </div>
                        <div class="toast-body">
                            ${message}
                        </div>
                    </div>
                </div>
            `);
            
            $('body').append(toast);
            
            // Auto remove after 5 seconds
            setTimeout(() => {
                toast.remove();
            }, 5000);
        }
        
        // Show success message
        function showSuccess(message) {
            // Remove existing toasts
            $('.toast').remove();
            
            const toast = $(`
                <div class="position-fixed top-0 end-0 p-3" style="z-index: 9999">
                    <div class="toast show" role="alert">
                        <div class="toast-header bg-success text-white">
                            <strong class="me-auto"><i class="fas fa-check-circle me-2"></i>Success</strong>
                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast"></button>
                        </div>
                        <div class="toast-body">
                            ${message}
                        </div>
                    </div>
                </div>
            `);
            
            $('body').append(toast);
            
            // Auto remove after 5 seconds
            setTimeout(() => {
                toast.remove();
            }, 5000);
        }
        
        // Check ticket
        function checkTicket() {
            const ticketCode = $('#checkTicketCode').val().trim();
            if(!ticketCode) {
                showError('Please enter ticket code');
                return;
            }
            
            $.ajax({
                url: 'api.php',
                method: 'POST',
                data: {
                    action: 'check_ticket',
                    ticket_code: ticketCode
                },
                success: function(response) {
                    if(response.success) {
                        let html = '<div class="alert alert-success">';
                        html += '<h6>Ticket Details</h6>';
                        html += '<p><strong>Code:</strong> ' + ticketCode + '</p>';
                        html += '<p><strong>Game:</strong> ' + response.game_name + '</p>';
                        html += '<p><strong>Player:</strong> ' + response.player_name + '</p>';
                        html += '<p><strong>Status:</strong> ' + (response.status === 'sold' ? 'Booked' : 'Available') + '</p>';
                        
                        if(response.patterns_completed && response.patterns_completed.length > 0) {
                            html += '<p><strong>Patterns Completed:</strong> ' + response.patterns_completed.join(', ') + '</p>';
                        }
                        
                        if(response.purchased_at) {
                            html += '<p><strong>Purchased:</strong> ' + new Date(response.purchased_at).toLocaleString() + '</p>';
                        }
                        
                        html += '</div>';
                        $('#yourTickets').html(html);
                    } else {
                        $('#yourTickets').html('<div class="alert alert-danger">' + (response.error || 'Ticket not found') + '</div>');
                    }
                },
                error: function() {
                    showError('Network error. Please try again.');
                }
            });
        }
        
        // Share on WhatsApp
        function shareOnWhatsApp(gameName, gameCode) {
            const gameUrl = window.location.origin + '/game.php?code=' + gameCode;
            const message = `🎯 Join me in DB Tambola!\n\nGame: ${gameName}\nCode: ${gameCode}\n\nClick to join: ${gameUrl}\n\nLet's play Housie together! 🎱`;
            
            const encodedMessage = encodeURIComponent(message);
            const whatsappUrl = `https://wa.me/?text=${encodedMessage}`;
            
            window.open(whatsappUrl, '_blank');
        }
        
        // Copy to clipboard
        function copyToClipboard(text, element) {
            navigator.clipboard.writeText(text).then(function() {
                const originalText = element.querySelector('.copy-text').innerHTML;
                element.querySelector('.copy-text').innerHTML = '<i class="fas fa-check"></i> Copied!';
                element.style.background = 'linear-gradient(135deg, #4CAF50, #2E7D32)';
                
                setTimeout(function() {
                    element.querySelector('.copy-text').innerHTML = originalText;
                    element.style.background = 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)';
                }, 2000);
                
                showSuccess('Copied to clipboard!');
            }).catch(function(err) {
                console.error('Failed to copy: ', err);
                showError('Failed to copy. Please copy manually: ' + text);
            });
        }
        
        // Join game
        function joinGame(gameCode) {
            window.location.href = 'game.php?code=' + gameCode;
        }
        
        // Update games list periodically BUT preserve disabled state
        setInterval(function() {
            $.get('api.php?action=get_active_games', function(data) {
                if(data.success && data.games) {
                    // Parse the new games HTML
                    const tempDiv = $('<div>').html(data.games);
                    
                    // Update each game card individually to preserve disabled state
                    tempDiv.find('.col-md-6').each(function() {
                        const gameId = $(this).attr('id');
                        if (gameId) {
                            // Check if this game was already started
                            const gameCode = gameId.replace('game-', '');
                            const wasStarted = startedGames[gameCode];
                            
                            if (wasStarted) {
                                // Find the choose ticket button and keep it disabled
                                $(this).find('.btn-custom').each(function() {
                                    const btn = $(this);
                                    if (btn.text().includes('Choose Tickets')) {
                                        btn.prop('disabled', true);
                                        btn.html('<i class="fas fa-ban me-2"></i>Game Started');
                                        btn.css({
                                            'background': 'linear-gradient(135deg, #cccccc, #999999)',
                                            'cursor': 'not-allowed'
                                        });
                                    }
                                });
                                
                                // Update the join button text
                                $(this).find('.btn-outline-primary').each(function() {
                                    const btn = $(this);
                                    if (!btn.text().includes('Watch Game')) {
                                        btn.html('<i class="fas fa-play-circle me-2"></i>Watch Game');
                                    }
                                });
                                
                                // Ensure the game started tag is present
                                if ($(this).find('.game-started-tag').length === 0) {
                                    $(this).find('.game-card').prepend(`
                                        <div class="game-started-tag">
                                            <i class="fas fa-play-circle me-1"></i> GAME STARTED
                                        </div>
                                    `);
                                }
                            }
                        }
                        
                        // Update this specific game card
                        $('#' + gameId).replaceWith($(this));
                    });
                    
                    // Update our tracking of started games
                    updateStartedGames();
                }
            });
        }, 10000);
        
        // Initialize when page loads
        $(document).ready(function() {
            console.log('DB Tambola initialized');
            
            // Make enter key work in check ticket input
            $('#checkTicketCode').on('keypress', function(e) {
                if(e.which === 13) {
                    checkTicket();
                }
            });
            
            // Make phone input accept only numbers
            $('#playerPhone').on('input', function() {
                this.value = this.value.replace(/[^0-9]/g, '');
                if(this.value.length > 10) {
                    this.value = this.value.slice(0, 10);
                }
            });
            
            // Initialize started games tracking
            updateStartedGames();
        });
        
        
        
      //REFRESH PAGE START CODE 
      // Refresh page when user navigates back to it
window.addEventListener('pageshow', function(event) {
    // Check if page was loaded from cache (back/forward button)
    if (event.persisted) {
        console.log('Page loaded from cache - refreshing...');
        window.location.reload();
    }
});

// OR using performance navigation API (alternative)
if (window.performance) {
    if (performance.navigation.type === 2) {
        // Type 2 = back/forward navigation
        console.log('Back/forward navigation detected - refreshing...');
        window.location.reload();
    }
}
  //REFRESH PAGE END CODE      
       
              
    </script>
</body>
</html>